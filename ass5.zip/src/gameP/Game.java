package gameP;
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;

import geometryP.Rectangle;
import logicP.BallRemover;
import logicP.BlockRemover;
import logicP.Counter;
import logicP.ScoreIndicator;
import logicP.ScoreTrackingListener;
import spriteP.Block;
import spriteP.Ball;
import spriteP.SpriteCollection;
import spriteP.Sprite;
import spriteP.Paddle;
import collisionP.Collidable;
import geometryP.Point;
import geometryP.Velocity;

/**
 * Ziv Glam
 * 327509105
 * assignment 5.
 */
public class Game {
    public static final int SCREEN_WIDTH = 800;
    public static final int SCREEN_HEIGHT = 600;
    public static final int WALL_CONST = 20;
    private static final Color BACKGROUND_COLOR = new Color(150, 100, 200);
    private SpriteCollection sprites = new SpriteCollection();
    private GameEnvironment environment = new GameEnvironment();
    private List<Ball> balls = new ArrayList<>();
    private Counter blockCount;
    private BlockRemover blockRemover;
    private BallRemover ballRemover;
    private ScoreTrackingListener score;
    private ScoreIndicator scoreIndicator;
    /**
     * Adds a collidable to the collidable list.
     * @param c collidable object to add
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }
    /**
     * Adds a sprite to the sprite list.
     * @param s sprite object
     */
    public void addSprite(Sprite s) {
        this.sprites.addSprite(s);
    }
    /**
     * remove a collidable from the game.
     * @param c collidable to remove
     */
    public void removeCollidable(Collidable c) {
        this.environment.removeCollidable(c);
    }
    /**
     * remove a sprite from the game.
     * @param s sprite to remove
     */
    public void removeSprite(Sprite s) {
        this.sprites.remove(s);
    }
    /**
     * Generates random color.
     * @return the color
     */
    public Color generateRandomColor() {
        Random random = new Random();
        int red, green, blue;
        //  Because gray is a special color, make sure nothing looks similar to it for better gaming experience.
        do {
            // Generate random values for red, green, and blue components
            red = random.nextInt(256);
            green = random.nextInt(256);
            blue = random.nextInt(256);
            // Return a new Color object with the random RGB values
        } while ((red <= 204 && red > 153 && green <= 204 && green > 153 && blue <= 204 && blue > 153)
                || (red <= 153 && red > 101 && green <= 153 && green > 101 && blue <= 153 && blue > 101));
        return new Color(red, green, blue);
    }
    /**
     * Initialize a new game: create the Blocks and shapesP.Ball(and shapesP.Paddle) and add them to the game.
     */
    public void initialize() {
        //  Creates block counter and blockRemover.
        blockCount = new Counter(0);
        blockRemover = new BlockRemover(this, this.blockCount);
        this.score = new ScoreTrackingListener(new Counter(0));
        //  Creates frame and border block.
        Block frame = new Block(new Point(0, 0), SCREEN_WIDTH, SCREEN_HEIGHT, BACKGROUND_COLOR);
        Block left = new Block(new Point(0, 20), WALL_CONST, 580, Color.GRAY);
        Block right = new Block(new Point(780, 20), WALL_CONST, 580, Color.GRAY);
        Block top = new Block(new Point(0, 20), SCREEN_WIDTH, WALL_CONST, Color.GRAY);
        Block bottom = new Block(new Point(20, 640), SCREEN_WIDTH, WALL_CONST, Color.GRAY);
        Rectangle rect = new Rectangle(new Point(0, 0), SCREEN_WIDTH, WALL_CONST);
        this.scoreIndicator = new ScoreIndicator(rect, Color.WHITE, new Counter(0));
        //  Sets the velocity changes for the border blocks according to border "rules".
        left.setVChange(-1);
        right.setVChange(-1);
        top.setVChange(-0.7);
        bottom.setVChange(-0.7);
        //  create balls.
        this.ballRemover = new BallRemover(this, new Counter(3));
        this.balls.add(new Ball(new Point(400, 550), 10, Color.black, this.environment));
        this.balls.add(new Ball(new Point(350, 500), 10, Color.black, this.environment));
        this.balls.add(new Ball(new Point(300, 500), 10, Color.black, this.environment));
        this.sprites.addSprite(frame);
        this.scoreIndicator.addToGame(this);
        bottom.addHitListener(this.ballRemover);
        //  add the balls to the sprite list.
        for (Ball ball : this.balls) {
            this.sprites.addSprite(ball);
        }
        //  add border blocks and balls to the game.
        bottom.addToGame(this);
        right.addToGame(this);
        left.addToGame(this);
        top.addToGame(this);
        //  creates blocks with random colors.
        for (int i = 12; i > 6; i--) {
            for (int j = 0; j < i; j++) {
                Block block = new Block(new Point(725 - 55 * j, 70 + 35 * (12 - i)), 55, 35,
                    generateRandomColor());
                //  count every non-gray blocks.
                if (!block.getC().equals(Color.GRAY)) {
                    this.blockCount.increase(1);
                }
                //  adds the block remover and score tracker as listeners.
                block.addHitListener(this.blockRemover);
                block.addHitListener(this.score);
                //  add the blocks in the sprites and collidable collections.
                block.addToGame(this);
            }
        }
        //  update ballRemover with the actual number of non-gray blocks.
        this.blockRemover.setRemainingBlocks(blockCount);
        //  set the velocity of every ball, but make sure they won't bounce only on the x-axis.
        Random rnd = new Random();
        for (int i = 0; i < this.balls.size(); i++) {
            do {
                this.balls.get(i).setVelocity(new Velocity(rnd.nextInt(-10, 10),
                        rnd.nextInt(-10, 10)));
            } while (this.balls.get(i).getV().getDy() == 0);
        }
    }
    /**
     * run the game.
     */
    public void run() {
        GUI gui = new GUI("arkanoid", 800, 600);
        //  create paddle.
        Paddle paddle = new Paddle(gui.getKeyboardSensor(), new Point(380, 570), 70, 10, Color.YELLOW);
        paddle.addToGame(this);
        Sleeper sleeper = new Sleeper();
        //  animate everything while there are blocks to be popped and balls to pop with.
            while (this.blockRemover.getRemainingBlocks().getValue() > 0
                    && this.ballRemover.getRemainingBalls().getValue() > 0) {
                DrawSurface d = gui.getDrawSurface();
                //  draw every sprite in the game.
                this.sprites.drawAllOn(d);
                gui.show(d);
                this.sprites.notifyAllTimePassed();
                this.scoreIndicator.setScoreCounter(this.score.getCurrentScore());
                sleeper.sleepFor(50); // wait for 50 milliseconds.
            }
            //  close the gui before exiting.
            gui.close();
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Game game = (Game) o;
        return Objects.equals(sprites, game.sprites) && Objects.equals(environment, game.environment)
                && Objects.equals(balls, game.balls) && Objects.equals(blockCount, game.blockCount)
                && Objects.equals(blockRemover, game.blockRemover)
                && Objects.equals(ballRemover, game.ballRemover) && Objects.equals(score, game.score);
    }
    @Override
    public int hashCode() {
        return Objects.hash(sprites, environment, balls, blockCount, blockRemover, ballRemover, score);
    }
    @Override
    public String toString() {
        return "Game{" + "sprites=" + sprites + ", environment=" + environment + ", balls=" + balls + ", blockCount="
                + blockCount + ", blockRemover=" + blockRemover + ", ballRemover=" + ballRemover
                + ", score=" + score + '}';
    }
}