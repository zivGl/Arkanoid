/**
 * Ziv Glam
 * 327509105
 * assignment 3.
 */
public interface Collidable {
    /**
     * Returns the "collision shape" of the object.
     * @return rectangle of the collidable object
     */
    Rectangle getCollisionRectangle();
    /**
     * Notify the object that we collided with at collisionPoint with a given velocity.
     * @param collisionPoint point of collision
     * @param currentVelocity velocity of the moving object that hit the collidable
     * @return new velocity expected after the hit (based on the force the object inflicted on us).
     */
    Velocity hit(Point collisionPoint, Velocity currentVelocity);
}