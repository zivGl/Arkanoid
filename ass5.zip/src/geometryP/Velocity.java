package geometryP;

import java.util.Objects;

/**
 * Ziv Glam
 * 327509105
 * assignment 5.
 */
public class Velocity {
    private double dx;
    private double dy;
    /**
     * Constructs velocity.
     * @param dx the change on the "x" axis
     * @param dy the change on the "y" axis
     */
    public Velocity(double dx, double dy) {
        this.dx = dx;
        this.dy = dy;
    }
    /**
     * Gets dx.
     * @return this dx
     */
    public Double getDx() {
        return this.dx;
    }
    /**
     * Gets dy.
     * @return this dy
     */
    public Double getDy() {
        return this.dy;
    }
    /**
     * Changes dx.
     * @param dx new dx
     */
    public void setDx(double dx) {
        this.dx = dx;
    }
    /**
     * Changes dy.
     * @param dy new dy
     */
    public void setDy(double dy) {
        this.dy = dy;
    }
    /**
     * Adds the velocity change to a point.
     * @param p what we add the velocity to
     * @return point after velocity
     */
    public Point applyToPoint(Point p) {
        return new Point(p.getX() + this.dx, p.getY() + this.dy);
    }
    /**
     * Converts angle and speed to dx and dy.
     * @param angle of the velocity
     * @param speed  of the velocity
     * @return the new velocity
     */
    public static Velocity fromAngleAndSpeed(double angle, double speed) {
        angle = Math.toRadians(angle);
        double dx = speed * Math.sin(angle);
        double dy = -speed * Math.cos(angle);
        return new Velocity(dx, dy);
    }
    /**
     * gets speed.
     * @return this speed
     */
    public double getSpeed() {
        return Math.sqrt(Math.pow(this.dx, 2) + Math.pow(this.dy, 2));
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Velocity velocity = (Velocity) o;
        return Double.compare(dx, velocity.dx) == 0 && Double.compare(dy, velocity.dy) == 0;
    }
    @Override
    public int hashCode() {
        return Objects.hash(dx, dy);
    }
    @Override
    public String toString() {
        return "Velocity{" + "dx=" + dx + ", dy=" + dy + '}';
    }
}