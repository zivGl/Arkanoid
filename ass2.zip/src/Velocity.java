import java.util.Random;
/**
 * Ziv Glam
 * 327509105
 * assignment 2.
 */
public class Velocity {
    private double dx;
    private double dy;
    /**
     * Constructs velocity randomly.
     */
    public Velocity() {
        Random rnd = new Random();
        this.dx = rnd.nextDouble(10) + 1;
        this.dy = rnd.nextDouble(10) + 1;
    }
    /**
     * Constructs velocity.
     * @param dx the change on the "x" axis
     * @param dy the change on the "y" axis
     */
    public Velocity(double dx, double dy) {
        this.dx = dx;
        this.dy = dy;
    }
    /**
     * Gets dx.
     * @return this dx
     */
    public Double getDx() {
        return this.dx;
    }
    /**
     * Gets dy.
     * @return this dy
     */
    public Double getDy() {
        return this.dy;
    }
    /**
     * Changes dx.
     * @param dx new dx
     */
    public void setDx(double dx) {
        this.dx = dx;
    }
    /**
     * Changes dy.
     * @param dy new dy
     */
    public void setDy(double dy) {
        this.dy = dy;
    }
    /**
     * Adds the velocity change to a point.
     * @param p what we add the velocity to
     * @return point after velocity
     */
    public Point applyToPoint(Point p) {
        return new Point(p.getX() + this.dx, p.getY() + this.dy);
    }
    /**
     * Converts angle and speed to dx and dy.
     * @param angle of the velocity
     * @param speed  of the velocity
     * @return the new velocity
     */
    public static Velocity fromAngleAndSpeed(double angle, double speed) {
        double dx = angle;
        double dy = speed;
        return new Velocity(dx, dy);
    }
}
