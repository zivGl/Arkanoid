import biuoop.DrawSurface;
/**
 * Ziv Glam
 * 327509105
 * assignment 2.
 */
public class Ball {
    private Point center;
    private int r;
    private java.awt.Color color;
    private Velocity v;
    /**
     * Constructs a ball.
     * @param center of the ball
     * @param r for radius
     * @param color of the ball
     */
    public Ball(Point center, int r, java.awt.Color color) {
        this.center = center;
        this.r = r;
        this.color = color;
        this.v = new Velocity(0, 0);
    }
    /**
     * Gets x of center.
     * @return x of Ball
     */
    public int getX() {
        return (int) this.center.getX();
    }
    /**
     * Gets y of center.
     * @return y of Ball
     */
    public int getY() {
        return (int) this.center.getY();
    }
    /**
     * Gets center of ball.
     * @return center of Ball
     */
    public Point getCenter() {
        return this.center;
    }
    /**
     * Gets radius.
     * @return radius of Ball
     */
    public int getSize() {
        return this.r;
    }
    /**
     * Gets color.
     * @return color of Ball
     */
    public java.awt.Color getColor() {
        return this.color;
    }
    /**
     * draw the ball on a given surface.
     * @param surface what to draw on
     */
    public void drawOn(DrawSurface surface) {
        surface.drawCircle(getX(), getY(), this.r);
    }
    /**
     * draw a filled ball on a given surface.
     * @param surface what to draw on
     */
    public void fillOn(DrawSurface surface) {
        surface.fillCircle(getX(), getY(), this.r);
    }
    /**
     * Sets the velocity of the ball.
     * @param v = velocity
     */
    public void setVelocity(Velocity v) {
        this.v = v;
    }
    /**
     * Gets the velocity of balls.
     * @return velocity
     */
    public Velocity getVelocity() {
        return this.v;
    }
    /**
     * moves the ball one step according to its velocity.
     * @param s rectangle the ball should stay in
     */
    public void moveOneStep(Rectangle s) {
        Point next = new Point(this.center.getX() + this.v.getDx(), this.center.getY() + this.v.getDy());
        Point right = new Point(next.getX() + r, next.getY());
        Point left = new Point(next.getX() - r, next.getY());
        Point top = new Point(next.getX(), next.getY() - r);
        Point bottom = new Point(next.getX(), next.getY() + r);
        Line lineTop = new Line(next, top);
        Line lineBottom = new Line(next, bottom);
        Line lineLeft = new Line(next, left);
        Line lineRight = new Line(next, right);
        //  Checks collision with s.
        if (s.getLeft().isIntersecting(lineLeft) || s.getRight().isIntersecting(lineRight)) {
            this.v.setDx(-1 * this.v.getDx());
        }
        if (s.getTop().isIntersecting(lineTop) || s.getBottom().isIntersecting(lineBottom)) {
            this.v.setDy(-1 * this.v.getDy());
        }
        this.center = this.v.applyToPoint(this.center);
    }
    /**
     * moves the ball one step according to its velocity.
     * @param frame where the ball should stay within
     * @param s rectangle the ball should stay out of
     */
    public void moveOneStep(Rectangle frame, Rectangle s) {
        Point next = new Point(this.center.getX() + this.v.getDx(), this.center.getY() + this.v.getDy());
        Point right = new Point(next.getX() + r, next.getY());
        Point left = new Point(next.getX() - r, next.getY());
        Point top = new Point(next.getX(), next.getY() - r);
        Point bottom = new Point(next.getX(), next.getY() + r);
        Line lineTop = new Line(next, top);
        Line lineBottom = new Line(next, bottom);
        Line lineLeft = new Line(next, left);
        Line lineRight = new Line(next, right);
        //  Checks collision with the squares on the x-axis.
        if (frame.getLeft().isIntersecting(lineLeft) || frame.getRight().isIntersecting(lineRight)
                || (s.getLeft().isIntersecting(lineLeft) || s.getRight().isIntersecting(lineRight))
                || (frame.getLeft().isIntersecting(lineRight) || frame.getRight().isIntersecting(lineLeft))
                || (s.getLeft().isIntersecting(lineRight) || s.getRight().isIntersecting(lineLeft))) {
            this.v.setDx(-1 * this.v.getDx());
        }
        //  Checks collision with the squares on the y-axis.
        if (frame.getTop().isIntersecting(lineTop) || frame.getBottom().isIntersecting(lineBottom)
                || (s.getTop().isIntersecting(lineTop) || s.getBottom().isIntersecting(lineBottom))
                || (frame.getTop().isIntersecting(lineBottom) || frame.getBottom().isIntersecting(lineTop))
                || (s.getTop().isIntersecting(lineBottom) || s.getBottom().isIntersecting(lineTop))) {
            this.v.setDy(-1 * this.v.getDy());
        }
        this.center = this.v.applyToPoint(this.center);
    }
    /**
     * moves the ball one step according to its velocity.
     * @param frame rectangle the ball should stay in
     * @param s1 a rectangle the ball should avoid
     * @param s2 a rectangle the ball should avoid
     */
    public void moveOneStep(Rectangle frame, Rectangle s1, Rectangle s2) {
        Point next = new Point(this.center.getX() + this.v.getDx(), this.center.getY() + this.v.getDy());
        Point right = new Point(next.getX() + r, next.getY());
        Point left = new Point(next.getX() - r, next.getY());
        Point top = new Point(next.getX(), next.getY() - r);
        Point bottom = new Point(next.getX(), next.getY() + r);
        Line lineTop = new Line(next, top);
        Line lineBottom = new Line(next, bottom);
        Line lineLeft = new Line(next, left);
        Line lineRight = new Line(next, right);
        //  Checks collision with the squares on the x-axis.
        if (frame.getLeft().isIntersecting(lineLeft) || frame.getRight().isIntersecting(lineRight)
                || (s1.getLeft().isIntersecting(lineLeft) || s1.getRight().isIntersecting(lineRight))
                || (s2.getLeft().isIntersecting(lineLeft) || s2.getRight().isIntersecting(lineRight))
                || (s1.getLeft().isIntersecting(lineRight) || s1.getRight().isIntersecting(lineLeft))
                || (s2.getLeft().isIntersecting(lineRight) || s2.getRight().isIntersecting(lineLeft))
                || (s1.getTop().isIntersecting(lineLeft) || s1.getBottom().isIntersecting(lineLeft))
                || (s2.getTop().isIntersecting(lineLeft) || s2.getBottom().isIntersecting(lineLeft))
                || (s1.getTop().isIntersecting(lineRight) || s1.getBottom().isIntersecting(lineRight))
                || (s2.getTop().isIntersecting(lineRight) || s2.getBottom().isIntersecting(lineRight))) {
            this.v.setDx(-1 * this.v.getDx());
        }
        //  Checks collision with the squares on the y-axis.
        if (frame.getTop().isIntersecting(lineTop) || frame.getBottom().isIntersecting(lineBottom)
                || (s2.getTop().isIntersecting(lineTop) || s2.getBottom().isIntersecting(lineBottom))
                || (s1.getTop().isIntersecting(lineTop) || s1.getBottom().isIntersecting(lineBottom))
                || (s1.getTop().isIntersecting(lineBottom) || s1.getBottom().isIntersecting(lineTop))
                || (s2.getTop().isIntersecting(lineBottom) || s2.getBottom().isIntersecting(lineTop))
                || (s1.getTop().isIntersecting(lineLeft) || s1.getBottom().isIntersecting(lineLeft))
                || (s2.getTop().isIntersecting(lineLeft) || s2.getBottom().isIntersecting(lineLeft))
                || (s1.getTop().isIntersecting(lineRight) || s1.getBottom().isIntersecting(lineRight))
                || (s2.getTop().isIntersecting(lineRight) || s2.getBottom().isIntersecting(lineRight))) {
            this.v.setDy(-1 * this.v.getDy());
        }
        this.center = this.v.applyToPoint(this.center);
    }
}