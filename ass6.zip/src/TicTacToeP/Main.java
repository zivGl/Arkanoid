package TicTacToeP;

import java.util.Scanner;

/**
 * Ziv Glam
 * 327509105
 * assignment 6.
 */
public class Main {
    /**
     * run the game.
     * @param args user parameters
     */
    public static void main(String[] args) {
        Scanner mainScanner = new Scanner(System.in);
        Player player1;
        Player player2;
        //  print message.
        System.out.println("Welcome to TicTacToe!\nChoose game mode:\n1. Player vs Player\n2. Player vs Computer"
                + "\n3. Computer vs Computer");
        String choice = mainScanner.nextLine();
        //  play the game according to the choice of the player.
        switch (choice) {
            case "1":
                //  Human vs Human.
                player1 = new Player("PLAYER-X", 1, 'X');
                player2 = new Player("PLAYER-O", 2, 'O');
                break;
            case "2":
                //  Human vs Computer.
                System.out.println("Do you want to play as X or O? (X plays first)");
                String playerSymbol = mainScanner.nextLine().toUpperCase();
                //  check mark choice.
                if (playerSymbol.equals("X")) {
                    player1 = new Player("PLAYER-X", 1, 'X');
                    player2 = new AutoPlayer("COMPUTER-O", 2, 'O');
                } else {
                    player1 = new AutoPlayer("COMPUTER-X", 1, 'X');
                    player2 = new Player("PLAYER-O", 2, 'O');
                }
                break;
            case "3":
                //  Computer vs Computer.
                player1 = new AutoPlayer("COMPUTER-X", 1, 'X');
                player2 = new AutoPlayer("COMPUTER-O", 2, 'O');
                break;
            default:
                System.out.println("Invalid choice. Defaulting to Player vs Player");
                player1 = new Player("PLAYER-X", 1, 'X');
                player2 = new Player("PLAYER-O", 2, 'O');
        }
        //  Create and start the game.
        TicTacToe game = new TicTacToe(player1, player2);
        game.play();
        //  close the scanner.
        mainScanner.close();
    }
}