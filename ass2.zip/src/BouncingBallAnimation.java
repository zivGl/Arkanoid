import biuoop.DrawSurface;
import biuoop.Sleeper;
import biuoop.GUI;
import java.awt.Color;
import java.util.Random;
/**
 * Ziv Glam
 * 327509105
 * assignment 2.
 */
public class BouncingBallAnimation {
    /**
     * Generates random color.
     * @return the color
     */
    public Color generateRandomColor() {
        Random random = new Random();
        // Generate random values for red, green, and blue components
        int red = random.nextInt(256);
        int green = random.nextInt(256);
        int blue = random.nextInt(256);
        // Return a new Color object with the random RGB values
        return new Color(red, green, blue);
    }
    /**
     * Draws a ball with animation.
     * @param start = start of ball
     * @param dx = change in "x" axis
     * @param dy = change in "y" axis
     */
    public void drawAnimation(Point start, double dx, double dy) {
        //  Generates a ball, square and the surface it's animated on.
        GUI gui = new GUI("title", 400, 300);
        Sleeper sleeper = new Sleeper();
        Rectangle frame = new Rectangle(new Point(0, 0), new Point(400, 300));
        Ball ball = new Ball(start, 30, generateRandomColor());
        ball.setVelocity(new Velocity(dx, dy));
        //  Animates the ball.
        while (true) {
            DrawSurface d = gui.getDrawSurface();
            ball.moveOneStep(frame);
            ball.drawOn(d);
            gui.show(d);
            sleeper.sleepFor(50); // wait for 50 milliseconds.
        }
    }
    /**
     * Main class.
     * @param args user's parameters
     */
    public static void main(String[] args) {
        BouncingBallAnimation example = new BouncingBallAnimation();
        int x = Integer.parseInt(args[0]);
        int y = Integer.parseInt(args[1]);
        //  Checks if the start point is in a valid place to start. If not, adds radius + 1.
        if (x < 30) {
            x += 31;
        }
        if (y < 30) {
            y += 31;
        }
        example.drawAnimation(new Point(x, y), Integer.parseInt(args[2]), Integer.parseInt(args[3]));
    }
}