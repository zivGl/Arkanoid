/**
 * Ziv Glam
 * 327509105
 * assignment 3.
 */
public class Ass3Game {
    /**
     * runs the game.
     * @param args user values
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.initialize();
        game.run();
    }
}
