import tkinter as tk
from tkinter import messagebox
import random
# Ziv Glam
# 327509105
# Assignment 7


class Cell:
    def __init__(self):
        self.state = "hidden"
        self.is_mine = False
        self.neighbor_bomb_count = 0

    # flag/unflag a cell
    def toggle_flag(self):
        if self.state == "hidden":
            self.state = "flagged"
            return True
        elif self.state == "flagged":
            self.state = "hidden"
            return True
        return False

    # reveal a cell
    def reveal(self):
        if self.state == "hidden":
            self.state = "revealed"
            return True
        return False


class GameBoard:
    # constructor of GameBoard objects
    def __init__(self, size, bombs):
        self.size = size
        self.bombs = bombs
        self.cells = [[Cell() for _ in range(size)] for _ in range(size)]
        self.place_bombs()
        self.calculate_neighbor_bombs()

    # randomly place the number of bombs given by the user
    def place_bombs(self):
        placed_bombs = 0
        while placed_bombs < self.bombs:
            x = random.randint(0, self.size - 1)
            y = random.randint(0, self.size - 1)
            if not self.cells[x][y].is_mine:
                self.cells[x][y].is_mine = True
                placed_bombs += 1

    # calculate the number of neighboring bombs that each cell has
    def calculate_neighbor_bombs(self):
        for x in range(self.size):
            for y in range(self.size):
                if self.cells[x][y].is_mine:
                    continue
                count = 0
                for nx, ny in self.get_neighbor_positions(x, y):
                    if self.cells[nx][ny].is_mine:
                        count += 1
                self.cells[x][y].neighbor_bomb_count = count

    # returns the position of a cell's neighbors
    def get_neighbor_positions(self, x, y):
        neighbors = []
        for dx in [-1, 0, 1]:
            for dy in [-1, 0, 1]:
                if dx == 0 and dy == 0:
                    continue
                nx, ny = x + dx, y + dy
                if 0 <= nx < self.size and 0 <= ny < self.size:
                    neighbors.append((nx, ny))
        return neighbors

class GuiWindow:
    # constructor of GuiWindow objects
    def __init__(self, master, minesweeper):
        self.master = master
        self.minesweeper = minesweeper
        self.create_widgets()

    # create widgets for the gui
    def create_widgets(self):
        for x in range(self.minesweeper.board.size):
            for y in range(self.minesweeper.board.size):
                btn = tk.Button(
                    self.master,
                    width=2,
                    height=1,
                    bg="light gray",
                    command=lambda x=x, y=y: self.minesweeper.reveal_cell(x, y)
                )
                btn.bind("<Button-3>", lambda e, x=x, y=y: self.minesweeper.toggle_flag(x, y))
                btn.grid(row=x, column=y)
                self.minesweeper.buttons[x][y] = btn

class Minesweeper:
    # constructor of Minesweeper objects
    def __init__(self, master, size, bomb_count):
        self.master = master
        self.board = GameBoard(size, bomb_count)
        self.buttons = [[None for _ in range(size)] for _ in range(size)]
        self.gui = GuiWindow(master, self)
        self.game_over = False

    # reveal a cell
    def reveal_cell(self, x, y):
        if self.game_over:
            return
        cell = self.board.cells[x][y]
        if cell.state == "hidden":
            # if hit a mine, the game is over
            if cell.is_mine:
                self.show_game_over()
                quit()
            else:
                cell.reveal()
                self.update_button(x, y)

                # reveal immediate neighbors
                for nx, ny in self.board.get_neighbor_positions(x, y):
                    neighbor_cell = self.board.cells[nx][ny]
                    if neighbor_cell.state == "hidden" and not neighbor_cell.is_mine:
                        neighbor_cell.reveal()
                        self.update_button(nx, ny)

                # Check for win condition
                if self.check_win_condition():
                    self.show_game_won()
                    quit()

    # toggle a cell to flagged position
    def toggle_flag(self, x, y):
        if self.game_over:
            quit()
            return
        cell = self.board.cells[x][y]
        if cell.toggle_flag():
            self.update_button(x, y)

    # update the button of a cell
    def update_button(self, x, y):
        cell = self.board.cells[x][y]
        btn = self.buttons[x][y]
        if cell.state == "revealed":
            if cell.is_mine:
                btn.config(text="💣", bg="red")  # Show mine
            elif cell.neighbor_bomb_count == 0:
                btn.config(text="", bg="white")  # Show empty cell for 0 bombs
            else:
                btn.config(text=str(cell.neighbor_bomb_count), bg="white")  # Show number of neighboring bombs
        elif cell.state == "flagged":
            btn.config(text="🚩", bg="yellow")  # Show flag
        else:
            btn.config(text="", bg="light gray")  # Default state

    # let the player know he lost
    def show_game_over(self):
        self.game_over = True
        # Reveal all cells
        for x in range(self.board.size):
            for y in range(self.board.size):
                cell = self.board.cells[x][y]
                if cell.is_mine:
                    cell.reveal()
                    self.update_button(x, y)  # Show the mine
                elif cell.state == "hidden":
                    cell.state = "revealed"  # Reveal non-mine cells

        # tell the player the game is over
        messagebox.showinfo("Game Over", "You hit a bomb!")

    # show the board and let the player know he won
    def show_game_won(self):
        self.game_over = True
        # reveal all cells after the game has been won
        for x in range(self.board.size):
            for y in range(self.board.size):
                cell = self.board.cells[x][y]
                cell.reveal()
                self.update_button(x, y)  # Show the revealed cell

        # Show a message box to inform the player
        messagebox.showinfo("Congratulations!", "You won the game!")

    # check if every non-bomb cell ha been revealed
    def check_win_condition(self):
        for x in range(self.board.size):
            for y in range(self.board.size):
                cell = self.board.cells[x][y]
                if (not cell.is_mine) and cell.state == "hidden":
                    return False
        return True


# main:
if __name__ == "__main__":
    # receive size of board and bomb number from user
    s = int(input("Enter the size of the board: "))
    b = int(input("Enter the number of bombs: "))
    # create a gui
    root = tk.Tk()
    root.resizable(True, True)
    # create a game
    game = Minesweeper(root, size=s, bomb_count=b)
    root.mainloop()
