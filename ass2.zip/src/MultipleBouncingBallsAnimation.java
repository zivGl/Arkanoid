import biuoop.DrawSurface;
import biuoop.Sleeper;
import biuoop.GUI;
import java.awt.Color;
import java.util.Random;
/**
 * Ziv Glam
 * 327509105
 * assignment 2.
 */
public class MultipleBouncingBallsAnimation {
    /**
     * Generates random color.
     * @return the color
     */
    public Color generateRandomColor() {
        Random random = new Random();
        // Generate random values for red, green, and blue components
        int red = random.nextInt(256);
        int green = random.nextInt(256);
        int blue = random.nextInt(256);
        // Return a new Color object with the random RGB values
        return new Color(red, green, blue);
    }
    /**
     * Generates a random ball with known limits.
     * @param frame where ball should be in
     * @param r radius of the ball
     * @return a ball
     */
    public Ball generateRandomBall(Rectangle frame, int r) {
        Random rand = new Random();
        // Generate random x-coordinate within valid range
        double x = rand.nextDouble(frame.getWidth() - 2 * r) + frame.getBottom().start().getX() + r;
        // Generate random y-coordinate within valid range
        double y = rand.nextDouble(frame.getHeight() - 2 * r) + frame.getTop().start().getY() + r;
        // Create a point and assign a random color
        Point p = new Point(x, y);
        Color c = generateRandomColor();
        return new Ball(p, r, c);
    }
    /**
     * Animates the balls.
     * @param balls balls to animate
     * @param frame frame of the balls
     */
    public void drawAnimation(Ball[] balls, Rectangle frame) {
        Velocity v;
        //  Iterate through every ball and gives it speed.
        for (int i = 0; i < balls.length; i++) {
            v = new Velocity();
            balls[i].setVelocity(v);
        }
        //  Draws all the balls on a surface and animates them.
        GUI gui = new GUI("title", 400, 300);
        Sleeper sleeper = new Sleeper();
        while (true) {
            DrawSurface d = gui.getDrawSurface();
            for (Ball b : balls) {
                b.moveOneStep(frame);
                b.drawOn(d);
            }
            gui.show(d);
            sleeper.sleepFor(50);
        }
    }
    /**
     * Main class.
     * @param args user's parameters
     */
    public static void main(String[] args) {
        //  Generates the balls and a frame.
        Ball[] balls = new Ball[args.length];
        MultipleBouncingBallsAnimation example = new MultipleBouncingBallsAnimation();
        Rectangle frame = new Rectangle(new Point(0, 0), new Point(400, 300));
        //  Randomly generates starting positions to every ball.
        for (int i = 0; i < balls.length; i++) {
            balls[i] = example.generateRandomBall(frame, Integer.parseInt(args[i]) + 10);
        }
        //  Runs animation method for the user's balls.
        example.drawAnimation(balls, frame);
    }
}
