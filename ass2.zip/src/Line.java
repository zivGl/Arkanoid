/**
 * Ziv Glam
 * 327509105
 * assignment 2.
 */
public class Line {
    private Point start;
    private Point end;
    /**
     * Constructing a line with 2 points.
     * @param start = start
     * @param end = end
     */
    public Line(Point start, Point end) {
        this.start = start;
        this.end = end;
    }
    /**
     * Constructing a line with 2 coordinates.
     * @param x1 = start.x
     * @param y1 = start.y
     * @param x2 = end.x
     * @param y2 = end.y
     */
    public Line(double x1, double y1, double x2, double y2) {
        this.start = new Point(x1, y1);
        this.end = new Point(x2, y2);
    }
    /**
     * Calculates the length of a line.
     * @return length of the line
     */
    public double length() {
        return this.start.distance(this.end);
    }
    /**
     * Calculates the middle point of the line.
     * @return the middle point
     */
    public Point middle() {
        return new Point((this.start.getX() + this.end.getX()) / 2, (this.start.getY() + this.end.getY()) / 2);
    }
    /**
     * Gets the start point of the line.
     * @return start point
     */
    public Point start() {
        return this.start;
    }
    /**
     * Gets the end point of the line.
     * @return end point
     */
    public Point end() {
        return this.end;
    }
    /**
     * Calculates if 2 lines intersect.
     * @param other = another line
     * @return true if intersects, false if not
     */
    public boolean isIntersecting(Line other) {
        if (intersectionWith(other) != null) {
            return true;
        }
        return false;
    }
    /**
     * Calculates if a line intersects with 2 other ones.
     * @param other1 = a line
     * @param other2 = another line
     * @return true if these 2 intersect with the current line, false if not
     */
    public boolean isIntersecting(Line other1, Line other2) {
        return isIntersecting(other1) && isIntersecting(other2);
    }
    /**
     * Calculates the intersection point of 2 lines.
     * @param other = another line
     * @return the intersection point if exists, null otherwise or if both lines are the same
     */
    public Point intersectionWith(Line other) {
        //  Checks if the lines are the same.
        if (equals(other)) {
            return null;
        }
        double m1, m2, b1, b2;
        // Calculate slopes and intersections.
        if (this.start.getX() == this.end.getX()) {
            double x = this.start.getX();
            m2 = (other.start.getY() - other.end.getY()) / (other.start.getX() - other.end.getX());
            b2 = other.start.getY() - m2 * other.start.getX();
            //  Calculate y using the other line's equation.
            double y = m2 * x + b2;
            //  Checks if the intersection point is within the bounds of the other line.
            if (isBetween(this.start.getY(), this.end.getY(), y)
                     && isBetween(other.start.getX(), other.end.getX(), x)) {
                return new Point(x, y);
            } else {
                return null;
            }
        } else if (other.start.getX() == other.end.getX()) {
            double x = other.start.getX();
            m1 = (this.start.getY() - this.end.getY()) / (this.start.getX() - this.end.getX());
            b1 = this.start.getY() - m1 * this.start.getX();
            //  Calculates y using this line's equation.
            double y = m1 * x + b1;
            //  Checks if the intersection point is within the bounds of this line.
            if (isBetween(other.start.getY(), other.end.getY(), y)
                    && isBetween(this.start.getX(), this.end.getX(), x)) {
                return new Point(x, y);
            } else {
                return null;
            }
        }
        //  Takes care of 2 regular lines.
        m1 = (this.start.getY() - this.end.getY()) / (this.start.getX() - this.end.getX());
        m2 = (other.start.getY() - other.end.getY()) / (other.start.getX() - other.end.getX());
        b1 = this.start.getY() - m1 * this.start.getX();
        b2 = other.start.getY() - m2 * other.start.getX();
        //  Check if lines are parallel.
        if (m1 == m2) {
            return null;
        }
        //  Calculate intersection point.
        double x = (b2 - b1) / (m1 - m2);
        double y = m1 * x + b1;
        //  Checks if intersection point is within both segments.
        if (isBetween(this.start.getX(), this.end.getX(), x) && isBetween(other.start.getX(), other.end.getX(), x)
                && isBetween(this.start.getY(), this.end.getY(), y)
                && isBetween(other.start.getY(), other.end.getY(), y)) {
            return new Point(x, y);
        }
        return null;
    }
    /**
     * Checks if a certain value is between 2 values.
     * @param start one border
     * @param end second border
     * @param value value to check
     * @return true if value is in the borders, false otherwise
     */
    private boolean isBetween(double start, double end, double value) {
        return (Math.min(start, end) <= value && value <= Math.max(start, end));
    }
    /**
     * Calculates if 2 lines are equal.
     * @param other = another line
     * @return true if they're the same, false otherwise
     */
    public boolean equals(Line other) {
        return this.start.equals(other.start()) && this.end.equals(other.end());
    }
}