import biuoop.DrawSurface;
import biuoop.KeyboardSensor;

import java.awt.Color;
/**
 * Ziv Glam
 * 327509105
 * assignment 3.
 */
public class Paddle extends Block implements Sprite, Collidable {
    private biuoop.KeyboardSensor keyboard;
    private Velocity speed;
    private double gameWidth = 800;
    /**
     * Constructs a paddle by creating a block.
     * @param keyboard keyboard of the gui
     * @param upperLeft point of the block
     * @param width of block
     * @param height of block
     * @param c color of block
     */
    public Paddle(KeyboardSensor keyboard, Point upperLeft, double width, double height, Color c) {
        super(upperLeft, width, height, c);
        this.speed = new Velocity(10, 0);
        this.keyboard = keyboard;
    }
    /**
     * Moves the paddle left.
     */
    public void moveLeft() {
        //  makes sure paddle moves right.
        if (this.speed.getDx() >= 0) {
            this.speed.setDx(this.speed.getDx() * -1);
        }
        // calculates new position.
        Point newP = this.speed.applyToPoint(this.getUpperLeft());
        //  checks boundaries.
        if (this.getTop().start().getX() <= 20) {
            newP = new Point(gameWidth - 20 - this.getWidth(), this.getUpperLeft().getY());
        }
        this.setUpperLeft(newP);
        //  updates the lines to match the movement.
        this.getTop().moveLine(newP);
        this.getBottom().moveLine(newP);
        this.getLeft().moveLine(newP);
        this.getRight().moveLine(newP);
    }
    /**
     * Moves the paddle right.
     */
    public void moveRight() {
        //  makes sure paddle moves right.
        if (this.speed.getDx() <= 0) {
            this.speed.setDx(this.speed.getDx() * -1);
        }
        //  calculates new position.
        Point newP = this.speed.applyToPoint(this.getUpperLeft());
        //  checks boundaries.
        if (this.getTop().end().getX() >= gameWidth - 20) {
         newP = new Point(20, this.getUpperLeft().getY());
        }
        this.setUpperLeft(newP);
        //  updates the lines to match the movement.
        this.getTop().moveLine(newP);
        this.getBottom().moveLine(newP);
        this.getLeft().moveLine(newP);
        this.getRight().moveLine(newP);
    }
    /**
     * Notify the paddle that time has passed and pops it.
     */
    @Override
    public void timePassed() {
        //  checks if paddle needs to move right or left.
        if (this.keyboard.isPressed(keyboard.LEFT_KEY) || this.keyboard.isPressed("a")) {
            moveLeft();
        } else if (this.keyboard.isPressed(keyboard.RIGHT_KEY) || this.keyboard.isPressed("d")) {
            moveRight();
        }
    }
    /**
     * draws paddle on a given surface.
     * @param d surface to draw the sprite on
     */
    @Override
    public void drawOn(DrawSurface d) {
        super.drawOn(d);
    }
    /**
     * gets the rectangle shape of the paddle.
     * @return rectangle shape of paddle
     */
    @Override
    public Rectangle getCollisionRectangle() {
        return super.getCollisionRectangle();
    }
    /**
     * notifies the paddle that a collision has been made and acts accordingly.
     * @param collisionPoint point of collision
     * @param currentVelocity velocity of the moving object that hit the collidable
     * @return new velocity after hit
     */
    @Override
    public Velocity hit(Point collisionPoint, Velocity currentVelocity) {
        double dx = currentVelocity.getDx();
        double dy = currentVelocity.getDy();
        double speed = currentVelocity.getSpeed();
        int region = (int) ((collisionPoint.getX() - this.getUpperLeft().getX())
                / (this.getWidth() / 5)) + 1;
        switch (region) {
            case 1:
                return Velocity.fromAngleAndSpeed(300, speed);
            case 2:
                return Velocity.fromAngleAndSpeed(330, speed);
            case 4:
                return Velocity.fromAngleAndSpeed(30, speed);
            case 5:
                return Velocity.fromAngleAndSpeed(60, speed);
            default:
                return new Velocity(dx, -dy);
        }
    }
    /**
     * adds to game the paddle.
     * @param g game to add the paddle to
     */
    public void addToGame(Game g) {
        //  adds to the game via adding to collidable ad sprite lists.
        g.addSprite(this);
        g.addCollidable(this);
    }
}