package gameP;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import collisionP.Collidable;
import collisionP.CollisionInfo;
import geometryP.Line;
import geometryP.SortedPointList;
import geometryP.Point;
/**
 * Ziv Glam
 * 327509105
 * assignment 5.
 */
public class GameEnvironment {
    private List<Collidable> collList = new ArrayList<>();
    /**
     * adds the given collidable object to the game environment.
     * @param c an object the ball can collide with.
     */
    public void addCollidable(Collidable c) {
        this.collList.add(c);
    }
    /**
     * remove a collidable from the game environment.
     * @param c collidable to remove
     */
    public void removeCollidable(Collidable c) {
        this.collList.remove(c);
    }
    /**
     * Checks if there are any collisions of a line with a collidable object.
     * @param trajectory line of which we check collisions with
     * @return the information of the closest collision. If there are none, return null
     */
    public CollisionInfo getClosestCollision(Line trajectory) {
        //  Checks if there are no object to collide with.
        if (this.collList.isEmpty()) {
            return null;
        }
        //  Checks every collision with a collidable object and saves the closest collision info.
        SortedPointList sort = new SortedPointList();
        double minDist = Double.MAX_VALUE;
        CollisionInfo collisionInfo = null;
        for (Collidable c : this.collList) {
            //  Creates a list of points from a collision and sorts it.
            List<Point> cTemp = c.getCollisionRectangle().intersectionPoints(trajectory);
            sort.sortPointList(cTemp, trajectory.start());
            //  Checks if there are any collisions with a certain object.
            if (cTemp != null && !cTemp.isEmpty()) {
                //  If the distance is smaller than the current minimum, save collision info.
                if (trajectory.start().distance(cTemp.get(0)) < minDist) {
                    minDist = trajectory.start().distance(cTemp.get(0));
                    collisionInfo = new CollisionInfo(cTemp.get(0), c);
                }
            }
        }
        //  Returns the last saved collision info.
        return collisionInfo;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        GameEnvironment that = (GameEnvironment) o;
        return Objects.equals(collList, that.collList);
    }
    @Override
    public int hashCode() {
        return Objects.hashCode(collList);
    }

    @Override
    public String toString() {
        return "GameEnvironment{" + "collList=" + collList + '}';
    }
}