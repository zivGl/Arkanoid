package logicP;
import spriteP.Block;
import spriteP.Ball;
/**
 * Ziv Glam
 * 327509105
 * assignment 5.
 */
public interface HitListener {
    /**
     * call this method whenever the beingHit object is hit.
     * @param beingHit what got hit
     * @param hitter the thing that hit it
     */
    void hitEvent(Block beingHit, Ball hitter);
}
