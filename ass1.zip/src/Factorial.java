/**
 * 327509105 Ziv Glam
 */
public class Factorial {
    public static long factorialIter(long n){
        long t = 1;
        //  While n > 1 continue factoring, else, returns 1 as t doesn't change:
        while(n > 1){
            t*=n;
            n--;
        }
        return t;
    }

    public static long factorialRecursive(long n){
        //  While n > 1 factor n with the recursive call of n-1 until it reaches n = 1:
        if(n <= 1)
            return 1;
        return n * factorialRecursive(n-1);
    }
    public static void main(String[] args){
        //  Calls out the functions for Task #1:
        factorialIter(Integer.parseInt(args[0]));
        System.out.println(factorialRecursive(Integer.parseInt(args[0])));
    }
}
