import java.awt.Color;
/**
 * Ziv Glam
 * 327509105
 * assignment 2.
 */
public class Rectangle {
    private Line top;
    private Line bottom;
    private Line left;
    private Line right;
    private Color c;
    /**
     * A builder with known width and height. Usually for the frame.
     * @param p1 most top bottom point of the Rectangle
     * @param p2 most top right point of the Rectangle
     */
    public Rectangle(Point p1, Point p2) {
        this.top = new Line(p1.getX(), p1.getY(), p2.getX(), p1.getY());
        this.bottom = new Line(p1.getX(), p2.getY(), p2.getX(), p2.getY());
        this.left = new Line(p1.getX(), p1.getY(), p1.getX(), p2.getY());
        this.right = new Line(p2.getX(), p1.getY(), p2.getX(), p2.getY());
        this.c = null;
    }
    /**
     * A builder with 2 known points, and color. Usually for the 2 small Rectangles.
     * @param p1 most top bottom point of the Rectangle
     * @param p2 most top right point of the Rectangle
     * @param c filled color of the Rectangle
     */
    public Rectangle(Point p1, Point p2, Color c) {
        this.top = new Line(p1.getX(), p1.getY(), p2.getX(), p1.getY());
        this.bottom = new Line(p1.getX(), p2.getY(), p2.getX(), p2.getY());
        this.left = new Line(p1.getX(), p1.getY(), p1.getX(), p2.getY());
        this.right = new Line(p2.getX(), p1.getY(), p2.getX(), p2.getY());
        this.c = c;
    }
    /**
     * Gets the top line of the Rectangle.
     * @return top line.
     */
    public Line getTop() {
        return top;
    }
    /**
     * Gets the bottom line of the Rectangle.
     * @return bottom line.
     */
    public Line getBottom() {
        return bottom;
    }
    /**
     * Gets the left line of the Rectangle.
     * @return left line.
     */
    public Line getLeft() {
        return left;
    }
    /**
     * Gets the right line of the Rectangle.
     * @return right line.
     */
    public Line getRight() {
        return right;
    }
    /**
     * Gets color of Rectangle.
     * @return color of border
     */
    public Color getC() {
        return c;
    }
    /**
     * Returns width of rectangle using the bottom line.
     * @return bottom line length(width)
     */
    public double getWidth() {
        return this.bottom.length();
    }
    /**
     * Returns height of rectangle using the right line.
     * @return right line length(width)
     */
    public double getHeight() {
        return this.right.length();
    }
    /**
     * Sets top line of Rectangle.
     * @param top new top line
     */
    public void setTop(Line top) {
        this.top = top;
    }
    /**
     * Sets bottom line of Rectangle.
     * @param bottom new bottom line
     */
    public void setBottom(Line bottom) {
        this.bottom = bottom;
    }
    /**
     * Sets left line of Rectangle.
     * @param left new left line
     */
    public void setLeft(Line left) {
        this.left = left;
    }
    /**
     * Sets right line of Rectangle.
     * @param right new right line
     */
    public void setRight(Line right) {
        this.right = right;
    }
    /**
     * Sets color of Rectangle.
     * @param c new color
     */
    public void setC(Color c) {
        this.c = c;
    }
}
