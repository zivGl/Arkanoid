import java.util.Random;
/**
 * Ziv Glam
 * 327509105
 * assignment 3.
 */
public class Point {
    private double x;
    private double y;
    /**
     * Initializes a random point for the center of a ball.
     * @param r radius of designed ball
     */
    public Point(double r) {
        Random rnd = new Random();
        this.x = rnd.nextDouble(400 - r) + 1;
        this.y = rnd.nextDouble(300 - r) + 1;
    }
    /**
     * Initializes the point class.
     * @param x = x
     * @param y = y
     */
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }
    /**
     * Calculates the distance of 2 points.
     * @param other = another point
     * @return the distance of this point to the other point
     */
    public double distance(Point other) {
        double n = Math.sqrt(Math.pow(this.x - other.getX(), 2) + Math.pow(this.y - other.getY(), 2));
        return n;
    }
    /**
     * calculates if 2 points are equal.
     * @param other = another point
     * @return true is the points are equal, false otherwise
     */
    public boolean equals(Point other) {
        if (this.x == other.getX() && this.y == other.getY()) {
            return true;
        }
        return false;
    }
    /**
     * Gets x.
     * @return x
     */
    public double getX() {
        return this.x;
    }
    /**
     * Gets y.
     * @return y
     */
    public double getY() {
        return this.y;
    }
    /**
     * overrides toString method.
     */
    @Override
    public String toString() {
        return "x: " + this.x + "\ny: " + this.y;
    }
}