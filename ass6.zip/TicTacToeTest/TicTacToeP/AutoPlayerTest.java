package TicTacToeP;

import org.junit.Assert;
import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
public class AutoPlayerTest {

    @Test
    public void AutoPlayerTest (){
        //  check initialization case.
        AutoPlayer autoPlayer = new AutoPlayer("AUTO-X", 1, 'X');
        Board board = new Board(3);
        Assert.assertEquals("AUTO-X", autoPlayer.getName());
        Assert.assertEquals(1, autoPlayer.getId());
        Assert.assertEquals('X', autoPlayer.getMarker());
        Assert.assertEquals(0, autoPlayer.getNumberOfWins());
        //  check selection on empty board case.
        autoPlayer = new AutoPlayer("AUTO-X", 1, 'X');
        //  Make multiple moves to test randomness.
        Set<Integer> selectedPositions = new HashSet<>();
        for (int i = 0; i < 50; i++) {
            Board testBoard = new Board(3);
            autoPlayer.move(testBoard);
            //  find the position that was marked.
            for (int pos = 1; pos <= 9; pos++) {
                if (!testBoard.isValidPosition(String.valueOf(pos))) {
                    selectedPositions.add(pos);
                    break;
                }
            }
        }
        //  check if multiple different positions were selected.
        assertTrue("AutoPlayer should select different positions randomly", selectedPositions.size() > 1);
        //  check selection on part board case.
        autoPlayer = new AutoPlayer("AUTO-X", 1, 'X');
        board = new Board(3);
        //  fill positions.
        board.placeTheMove('O', 1);
        board.placeTheMove('O', 5);
        board.placeTheMove('O', 9);
        //  make multiple moves.
        selectedPositions = new HashSet<>();
        for (int i = 0; i < 50; i++) {
            Board testBoard = new Board(3);
            testBoard.placeTheMove('O', 1);
            testBoard.placeTheMove('O', 5);
            testBoard.placeTheMove('O', 9);
            autoPlayer.move(testBoard);
            //  find the marked position.
            for (int pos = 1; pos <= 9; pos++) {
                if (!testBoard.isValidPosition(String.valueOf(pos)) && pos != 1 && pos != 5 && pos != 9) {
                    selectedPositions.add(pos);
                    break;
                }
            }
        }
        //  check if multiple different positions were selected.
        assertTrue("AutoPlayer should select different available positions randomly",
                selectedPositions.size() > 1);
        assertFalse("AutoPlayer should not select occupied position 1", selectedPositions.contains(1));
        assertFalse("AutoPlayer should not select occupied position 5", selectedPositions.contains(5));
        assertFalse("AutoPlayer should not select occupied position 9", selectedPositions.contains(9));
        //  check moves on diff size board
        autoPlayer = new AutoPlayer("AUTO-X", 1, 'X');
        //  test on 4x4 board.
        Board largeBoard = new Board(4);
        autoPlayer.move(largeBoard);
        int occupiedCount = 0;
        for (int i = 1; i <= 16; i++) {
            if (!largeBoard.isValidPosition(String.valueOf(i))) {
                occupiedCount++;
            }
        }
        Assert.assertEquals(1, occupiedCount);
    }
}
