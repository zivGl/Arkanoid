import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;
import java.awt.Color;
import java.util.Random;
/**
 * Ziv Glam
 * 327509105
 * assignment 3.
 */
public class Game {
    private SpriteCollection sprites = new SpriteCollection();
    private GameEnvironment environment = new GameEnvironment();
    /**
     * Adds a collidable to the collidable list.
     * @param c collidable object to add
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }
    /**
     * Adds a sprite to the sprite list.
     * @param s sprite object
     */
    public void addSprite(Sprite s) {
        this.sprites.addSprite(s);
    }
    /**
     * Generates random color.
     * @return the color
     */
    public Color generateRandomColor() {
        Random random = new Random();
        // Generate random values for red, green, and blue components
        int red = random.nextInt(256);
        int green = random.nextInt(256);
        int blue = random.nextInt(256);
        // Return a new Color object with the random RGB values
        return new Color(red, green, blue);
    }
    /**
     * Initialize a new game: create the Blocks and Ball(and Paddle) and add them to the game.
     */
    public void initialize() {
        //  Creates frame and border block.
        Block frame = new Block(new Point(0, 0), 800, 600, Color.BLUE);
        Block left = new Block(new Point(0, 20), 20, 580, Color.GRAY);
        Block right = new Block(new Point(780, 20), 20, 580, Color.GRAY);
        Block top = new Block(new Point(0, 0), 800, 20, Color.GRAY);
        Block bottom = new Block(new Point(20, 580), 760, 20, Color.GRAY);
        //  Sets the velocity changes for the border blocks according to border "rules".
        left.setVChange(-1);
        right.setVChange(-1);
        top.setVChange(-0.7);
        bottom.setVChange(-0.7);
        //  Creates balls.
        Ball ball1 = new Ball(new Point(400, 550), 10, Color.black, this.environment);
        Ball ball2 = new Ball(new Point(300, 500), 10, Color.black, this.environment);
        //  Adds border blocks and balls to the sprite list and to the collidable list.
        addCollidable(frame);
        addSprite(frame);
        addSprite(ball1);
        addSprite(ball2);
        addCollidable(right);
        addSprite(right);
        addCollidable(left);
        addSprite(left);
        addCollidable(top);
        addSprite(top);
        addCollidable(bottom);
        addSprite(bottom);
        //  creates blocks with random colors.
        for (int i = 12; i > 6; i--) {
            for (int j = 0; j < i; j++) {
                Block b = new Block(new Point(725 - 55 * j, 50 + 35 * (12 - i)), 55, 35,
                    generateRandomColor());
                //  adds the blocks in the sprites and collidable collections.
                addCollidable(b);
                addSprite(b);
            }
        }
    }
    /**
     * run the game.
     */
    public void run() {
        GUI gui = new GUI("arkanoid", 800, 600);
        //  creates paddle.
        Paddle paddle = new Paddle(gui.getKeyboardSensor(), new Point(380, 570), 70, 10, Color.YELLOW);
        paddle.addToGame(this);
        Sleeper sleeper = new Sleeper();
        //  sets the velocity of the ball.
        ((Ball) this.sprites.getSpriteList().get(1)).setVelocity(new Velocity(7, 4));
        ((Ball) this.sprites.getSpriteList().get(2)).setVelocity(new Velocity(-3, 6));
        while (true) {
            //  animates everything.
            while (true) {
                DrawSurface d = gui.getDrawSurface();
                //  draw every sprite in the game.
                this.sprites.drawAllOn(d);
                gui.show(d);
                this.sprites.notifyAllTimePassed();
                sleeper.sleepFor(50); // wait for 50 milliseconds.
            }
        }
    }
}