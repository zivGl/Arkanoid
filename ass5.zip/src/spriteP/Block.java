package spriteP;

import biuoop.DrawSurface;
import gameP.Game;
import collisionP.Collidable;
import geometryP.Point;
import geometryP.Rectangle;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import geometryP.Velocity;
import logicP.HitListener;
import logicP.HitNotifier;

/**
 * Ziv Glam
 * 327509105
 * assignment 5.
 */
public class Block extends Rectangle implements Collidable, Sprite, HitNotifier {
    private List<HitListener> hitListeners;
    private double vChange = -1.05;
    /**
     * Constructor of blocks that creates a block with a point, width, height, color, and initializes a listener list.
     * @param upperLeft point of the block
     * @param width of block
     * @param height of block
     * @param c color of block
     */
    public Block(Point upperLeft, double width, double height, Color c) {
        super(upperLeft, width, height, c);
        this.hitListeners = new ArrayList<>();
    }
    /**
     * Implements getCollision rectangle method from the interface.
     * @return a rectangle that collides right now with an object
     */
    @Override
    public Rectangle getCollisionRectangle() {
        return this;
    }
    /**
     * Returns the new velocity after the hit of the block.
     * @param collisionPoint  (Point) the point where the hit occurred
     * @param currentVelocity (Velocity) the velocity of the object when the hit occurred
     * @param hitter (Ball) the ball that hit the object
     * @return (Velocity) the new velocity after the hit
     */
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        this.notifyHit(hitter);
        // The 4 points of the block.
        Point topLeft = this.getUpperLeft();
        Point topRight = new Point(topLeft.getX() + this.getWidth(), topLeft.getY());
        Point bottomLeft = new Point(topLeft.getX(), topLeft.getY() + this.getHeight());
        Point bottomRight = new Point(topLeft.getX() + this.getWidth(), topLeft.getY() + this.getHeight());
        // checks if the collision occurred at the corner of the paddle.
        for (Point point : new Point[]{topLeft, topRight, bottomLeft, bottomRight}) {
            if (collisionPoint.equals(point)) {
                return new Velocity(-currentVelocity.getDx(), -currentVelocity.getDy());
            }
        }
        // checks if the collision point occurred on the side of the block
        double diffX = this.getUpperLeft().getX() - collisionPoint.getX();
        double diffY = this.getUpperLeft().getY() - collisionPoint.getY();
        if (Math.abs(diffX) <= Point.THRESHOLD || Math.abs(diffX + this.getWidth()) <= Point.THRESHOLD) {
            return new Velocity(-currentVelocity.getDx(), currentVelocity.getDy());
        }
        // checks if the collision point occurred on the top/bottom of the block
        if (Math.abs(diffY) <= Point.THRESHOLD || Math.abs(diffY + this.getHeight()) <= Point.THRESHOLD) {
            return new Velocity(currentVelocity.getDx(), -currentVelocity.getDy());
        }
        return currentVelocity;
    }
    /**
     * Changes the change parameters in the vChange.
     * @param vChange new change in velocity after hit.
     */
    public void setVChange(double vChange) {
        this.vChange = vChange;
    }
    /**
     * Notify the block that time has passed and pops it.
     */
    @Override
    public void timePassed() {

    }
    /**
     * Draws a block with its color on a given surface. THIS CHANGES THE COLOR OF THE SURFACE.
     * @param surface where the block will get drawn on
     */
    @Override
    public void drawOn(DrawSurface surface) {
        //  Draws the outlines of the rectangle.
        surface.setColor(Color.BLACK);
        surface.drawRectangle((int) this.getUpperLeft().getX(), (int) this.getUpperLeft().getY(),
                (int) this.getWidth(), (int) this.getHeight());
        //  Fills the rectangle with its own color.
        surface.setColor(this.getC());
        surface.fillRectangle((int) this.getUpperLeft().getX(), (int) this.getUpperLeft().getY(),
                (int) this.getWidth(), (int) this.getHeight());
    }
    /**
     * check if current block's color matches that of a ball.
     * @param ball ball to check colors with
     * @return true if colors match, false otherwise
     */
    public boolean ballColorMatch(Ball ball) {
        return this.getC().equals(ball.getColor());
    }
    /**
     * Adds the sprite and collision box of the block to the game.
     * @param game (Game) the game to add the block to
     */
    public void addToGame(Game game) {
        game.addSprite(this);
        game.addCollidable(this);
    }
    /**
     * removes the block from the game.
     * @param game where we want the block removed from
     */
    public void removeFromGame(Game game) {
        game.removeSprite(this);
        game.removeCollidable(this);
    }
    /**
     * notify every listener of block.
     * @param hitter what hit the block
     */
    private void notifyHit(Ball hitter) {
        // Make a copy of the hitListeners before iterating over them.
        List<HitListener> listeners = new ArrayList<HitListener>(this.hitListeners);
        // Notify all listeners about a hit event:
        for (HitListener hl : listeners) {
            hl.hitEvent(this, hitter);
        }
    }
    /**
     * Add hl as a listener to hit events.
     * @param hl listener to add
     */
    @Override
    public void addHitListener(HitListener hl) {
        this.hitListeners.add(hl);
    }
    /**
     * Remove hl from the list of listeners to hit events.
     * @param hl listener to remove
     */
    @Override
    public void removeHitListener(HitListener hl) {
        this.hitListeners.remove(hl);
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Block block = (Block) o;
        return getUpperLeft().equals(((Block) o).getUpperLeft()) && Objects.equals(hitListeners, block.hitListeners);
    }
    @Override
    public int hashCode() {
        return Objects.hash(hitListeners, vChange);
    }
    @Override
    public String toString() {
        return "Block{" + "hitListeners=" + hitListeners + ", vChange=" + vChange + '}';
    }
}
