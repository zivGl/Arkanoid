package geometryP;

import java.util.List;
/**
 * Ziv Glam
 * 327509105
 * assignment 5.
 */
public class SortedPointList {
    /**
     * Sorts a List of points by measuring how far a point in the List is from a certain point.
     * @param list of points to sort
     * @param p known point to check distance from
     */
    public void sortPointList(List<Point> list, Point p) {
        //  Checks if the List is empty or null and cannot be sorted.
        if (list == null || list.isEmpty()) {
            return;
        }
        //  Sorts the List via bubbleSort.
        Object[] arr = list.toArray();
        Point t;
        for (int i = 0; i < arr.length; i++) {
            for (int j = i; j < arr.length; j++) {
                //  Checks if 2 elements need to be swapped and swaps if so.
                if (p.distance((Point) arr[i]) > p.distance((Point) arr[j])) {
                t = (Point) arr[i];
                    arr[i] = arr[j];
                    arr[j]  = t;
                }
            }
        }
        //  Builds the list anew but sorted.
        list.clear();
        for (int i = 0; i < arr.length; i++) {
            list.add((Point) arr[i]);
        }
    }
    @Override
    public String toString() {
        return "SortedPointList{}";
    }
}
