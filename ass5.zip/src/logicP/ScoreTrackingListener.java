package logicP;

import spriteP.Ball;
import spriteP.Block;

import java.util.Objects;

/**
 * Ziv Glam
 * 327509105
 * assignment 5.
 */
public class ScoreTrackingListener implements HitListener {
    private Counter currentScore;
    /**
     * builder of scoreTrackListener objects.
     * @param scoreCounter counter of score
     */
    public ScoreTrackingListener(Counter scoreCounter) {
        this.currentScore = scoreCounter;
    }
    /**
     * increase it according tp the game rules.
     * @param beingHit what got hit
     * @param hitter the thing that hit it
     */
    public void hitEvent(Block beingHit, Ball hitter) {
       this.currentScore.increase(5);
    }
    /**
     * get thw current score.
     * @return current score
     */
    public Counter getCurrentScore() {
        return currentScore;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ScoreTrackingListener that = (ScoreTrackingListener) o;
        return Objects.equals(currentScore, that.currentScore);
    }
    @Override
    public int hashCode() {
        return Objects.hashCode(currentScore);
    }
    @Override
    public String toString() {
        return "ScoreTrackingListener{" + "currentScore=" + currentScore + '}';
    }
}
