import biuoop.DrawSurface;
/**
 * Ziv Glam
 * 327509105
 * assignment 3.
 */
public interface Sprite {
    /**
     * Draw the sprite to the screen.
     * @param d surface to draw the sprite on
     */
    void drawOn(DrawSurface d);
    /**
     *  Notify the sprite that time has passed.
     */
    void timePassed();
}
