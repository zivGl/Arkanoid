package logicP;

import java.util.Objects;

/**
 * Ziv Glam
 * 327509105
 * assignment 5.
 */
public class Counter {
    private int count;
    /**
     * constructor of Counter objects.
     * @param count first number of the counter
     */
    public Counter(int count) {
        this.count = count;
    }
    /**
     * add number to current count.
     * @param number how much to increase
     */
    public void increase(int number) {
        this.count += number;
    }
    /**
     * subtract number to current count.
     * @param number how much to increase
     */
    public void decrease(int number) {
        this.count -= number;
    }
    /**
     * get current count.
     * @return count
     */
    public int getValue() {
        return this.count;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Counter counter = (Counter) o;
        return count == counter.count;
    }
    @Override
    public int hashCode() {
        return Objects.hashCode(count);
    }
    @Override
    public String toString() {
        return "" + this.count;
    }
}
