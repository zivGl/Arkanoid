package collisionP;

import geometryP.Point;
import geometryP.Rectangle;
import geometryP.Velocity;
import spriteP.Ball;

/**
 * Ziv Glam
 * 327509105
 * assignment 5.
 */
public interface Collidable {
    /**
     * Returns the "collision shape" of the object.
     * @return rectangle of the collidable object
     */
    Rectangle getCollisionRectangle();
    /**
     * Notify the object that we collided with at collisionPoint with a given velocity.
     * @param collisionPoint point of collision
     * @param currentVelocity velocity of the moving object that hit the collidable
     * @param hitter the ball that hit the block
     * @return new velocity expected after the hit (based on the force the object inflicted on us).
     */
    Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity);
}