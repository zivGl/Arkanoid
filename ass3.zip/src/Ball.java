import biuoop.DrawSurface;
/**
 * Ziv Glam
 * 327509105
 * assignment 3.
 */
public class Ball implements Sprite {
    private Point center;
    private int r;
    private java.awt.Color color;
    private Velocity v;
    private GameEnvironment game;
    /**
     * Constructs a ball.
     * @param center of the ball
     * @param r for radius
     * @param color of the ball
     * @param game Game environment of the ball
     */
    public Ball(Point center, int r, java.awt.Color color, GameEnvironment game) {
        this.center = center;
        this.r = r;
        this.color = color;
        this.v = new Velocity(0, 0);
        this.game = game;
    }
    /**
     * Gets x of center.
     * @return x of Ball
     */
    public int getX() {
        return (int) this.center.getX();
    }
    /**
     * Gets y of center.
     * @return y of Ball
     */
    public int getY() {
        return (int) this.center.getY();
    }
    /**
     * Gets center of ball.
     * @return center of Ball
     */
    public Point getCenter() {
        return this.center;
    }
    /**
     * Gets game environment.
     * @return game environment of ball
     */
    public GameEnvironment getGameEnvironment() {
        return this.game;
    }
    /**
     * draw a filled ball on a given surface. THIS CHANGES THE COLOR OF THE SURFACE.
     * @param surface what to draw on
     */
    @Override
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.color);
        surface.fillCircle(this.getX(), this.getY(), this.r);
    }
    /**
     * Notify the ball that time has passed and moves it.
     */
    @Override
    public void timePassed() {
        moveOneStep();
    }
    /**
     * Sets the velocity of the ball.
     * @param v = velocity
     */
    public void setVelocity(Velocity v) {
        this.v = v;
    }
    /**
     * moves the ball one step according to its velocity.
     */
    public void moveOneStep() {
        //  Indicates whether the radius should be added or subtracted to the trajectory point.
        int xDir, yDir;
        if (this.v.getDx() > 0) {
            xDir = 1;
        } else if (this.v.getDx() == 0) {
            xDir = 0;
        } else {
            xDir = -1;
        }
        if (this.v.getDy() > 0) {
            yDir = 1;
        } else if (this.v.getDy() == 0) {
            yDir = 0;
        } else {
            yDir = -1;
        }
        //  Creates a line of the trajectory the ball will move if no collisions are made.
        Point next = new Point(this.center.getX() + this.v.getDx() + xDir * this.r,
                this.center.getY() + this.v.getDy() + yDir * this.r);
        Line trajectory = new Line(this.center, next);
        //  Check the closest collision with the new line.
        CollisionInfo collisionInfo = this.game.getClosestCollision(trajectory);
        // If we have a collision, change the speed accordingly.
        if (collisionInfo != null) {
            this.setVelocity(collisionInfo.getCollisionObject().hit(collisionInfo.getCollisionPoint(), this.v));
        }
        //  Moves the point according to the new velocity.
        this.center = this.v.applyToPoint(this.center);
    }
}