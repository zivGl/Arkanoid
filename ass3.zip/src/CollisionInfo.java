/**
 * Ziv Glam
 * 327509105
 * assignment 3.
 */
public class CollisionInfo {
    private Point collisionPoint;
    private Collidable collisionObject;
    CollisionInfo(Point collisionPoint, Collidable collisionObject) {
        this.collisionPoint = collisionPoint;
        this.collisionObject = collisionObject;
    }
    /**
     * Gets collision point from a certain collision.
     * @return collision point
     */
    public Point getCollisionPoint() {
        return this.collisionPoint;
    }
    /**
     * Gets collision Object from a certain collision.
     * @return collision Object
     */
    public Collidable getCollisionObject() {
        return this.collisionObject;
    }
}