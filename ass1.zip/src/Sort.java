/**
 * 327509105 Ziv Glam
 */
public class Sort {
    public static int[] stringsToInts(String[] numbers){
        //  Converts a string of numbers to an array of integers without the sort order type:
        int[] nums = new int[numbers.length];
        for(int i = 1; i < numbers.length; i++){
            nums[i-1] = Integer.parseInt(numbers[i]);
        }
        return nums;
    }
    public static void sort(int[] nums, String type){
        int t;
        // Checks which type of sorting is wanted, and bubble-sorts accordingly:
        if(type.equals("desc")){
            for(int i = 0; i < nums.length; i++){
                for (int j = 0; j < nums.length; j++){
                    if(nums[i] > nums[j]){
                        t = nums[i];
                        nums[i] = nums[j];
                        nums[j]  = t;
                    }
                }
            }
        }
        else if (type.equals("asc")) {
            for(int i = 0; i < nums.length; i++){
                for (int j = 0; j < nums.length; j++){
                    if(nums[i] < nums[j]){
                        t = nums[i];
                        nums[i] = nums[j];
                        nums[j]  = t;
                    }
                }
            }
        }
        //  Prints the sorted array:
        for (int num : nums) {
            System.out.print(num + " ");
        }
    }
    public static void main(String[] args){
        //  Calls out the functions for Task #3:
        Sort.sort(Sort.stringsToInts(args), args[0]);
    }
}
