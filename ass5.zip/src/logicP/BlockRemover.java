package logicP;

import java.awt.Color;
import java.util.Objects;

import gameP.Game;
import spriteP.Ball;
import spriteP.Block;

/**
 * Ziv Glam
 * 327509105
 * assignment 5.
 */
public class BlockRemover implements HitListener {
    private Game game;
    private Counter remainingBlocks;
    /**
     * builder of BlockRemover objects.
     * @param game game the block remover should listen to
     * @param remainingBlocks how many blocks are left
     */
    public BlockRemover(Game game, Counter remainingBlocks) {
        this.game = game;
        this.remainingBlocks = remainingBlocks;
    }
    /**
     * check if the beingHit block should be removed. If so, remove it and decrease block count.
     * @param beingHit what got hit
     * @param hitter the thing that hit it
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        //  Notifies the block of the event that occurred.
        //  Remove every block that isn't a gray one.
        if (!beingHit.getC().equals(Color.GRAY) && !beingHit.ballColorMatch(hitter)) {
            hitter.setColor(beingHit.getC());
            beingHit.removeFromGame(this.game);
            beingHit.removeHitListener(this);
            //  Decrease the amount of remaining blocks.
            this.remainingBlocks.decrease(1);
        }
    }
    /**
     * get the blocks counter.
     * @return current counter of blocks
     */
    public Counter getRemainingBlocks() {
        return remainingBlocks;
    }
    /**
     * set the remaining blocks number.
     * @param remainingBlocks new number of remaining blocks
     */
    public void setRemainingBlocks(Counter remainingBlocks) {
        this.remainingBlocks = remainingBlocks;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        BlockRemover that = (BlockRemover) o;
        return Objects.equals(game, that.game) && Objects.equals(remainingBlocks, that.remainingBlocks);
    }
    @Override
    public int hashCode() {
        return Objects.hash(game, remainingBlocks);
    }
    @Override
    public String toString() {
        return "BlockRemover{" + "game=" + game + ", remainingBlocks=" + remainingBlocks + '}';
    }
}
