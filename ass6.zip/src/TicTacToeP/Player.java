package TicTacToeP;

import java.util.Scanner;

/**
 * Ziv Glam
 * 327509105
 * assignment 6.
 */
public class Player {
    private final int id;
    private final String name;
    private final char marker;
    private final Scanner sc;
    private int numberOfWins;

    /**
     * constructor of TicTacToeP.Player objects.
     * @param name name of player
     * @param id id of player
     * @param marker his type in the game(X or 0)
     */
    public Player(String name, int id, char marker) {
        this.id = id;
        this.name = name;
        this.numberOfWins = 0;
        this.marker = marker;
        sc = new Scanner(System.in);
    }

    /**
     * get the id of this player.
     * @return id
     */
    public int getId() {
        return this.id;
    }

    /**
     * get name of this player.
     * @return name
     */
    public String getName() {
        return this.name;
    }

    /**
     * get the mark of this player.
     * @return mark
     */
    public char getMarker() {
        return this.marker;
    }

    /**
     * get the scanner of this player.
     * @return scanner
     */
    public Scanner getSC() {
        return this.sc;
    }

    /**
     * close the scanner of this player.
     */
    public void closeSC() {
        this.sc.close();
    }

    /**
     * get the number of wins of current player.
     * @return number of wins so far
     */
    public int getNumberOfWins() {
        return this.numberOfWins;
    }

    /**
     * add a win for this player.
     */
    public void incrementNumberOfWins() {
        this.numberOfWins++;
    }

    /**
     * reset number of wins for this player.
     */
    public void resetNumberOfWins() {
        this.numberOfWins = 0;
    }

    /**
     * make a move for this current player.
     * @param board where to make the move in
     */
    public void move(Board board) {
        String movePos;

        while (true) {
            System.out.println("TicTacToeP.Player " + this.name + ", please enter your move. (enter a value from 1 - "
                    + board.getBoardSize() * board.getBoardSize() + ")");
            board.print();

            if (sc.hasNextLine()) {
                movePos = sc.nextLine();

                if (!board.isValidPosition(movePos)) {
                    System.out.println("Invalid move. Please try again.");
                } else {
                    break;
                }
            }
        }

        board.placeTheMove(this.marker, Integer.parseInt(movePos));
    }
}
