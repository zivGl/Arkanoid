package spriteP;
import biuoop.DrawSurface;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Ziv Glam
 * 327509105
 * assignment 5.
 */
public class SpriteCollection {
    private List<Sprite> spriteList = new ArrayList<>();
    /**
     * Adds a new sprite object to the list of sprites.
     * @param s sprite object to add
     */
    public void addSprite(Sprite s) {
        spriteList.add(s);
    }
    /**
     * remove a sprite from the sprite collection.
     * @param s sprite to remove
     */
    public void remove(Sprite s) {
        this.spriteList.remove(s);
    }
    /**
     * Calls timePassed() on all sprites.
     */
    public void notifyAllTimePassed() {
        // Make a copy of the hitListeners before iterating over them.
        List<Sprite> sprites = new ArrayList<>(this.spriteList);
        // Notify all listeners about a hit event:
        for (Sprite sprite : sprites) {
            sprite.timePassed();
        }
    }
    /**
     * Calls drawOn(d) on all sprites.
     * @param d surface to draw on
     */
    public void drawAllOn(DrawSurface d) {
        for (Sprite s : this.spriteList) {
            s.drawOn(d);
        }
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SpriteCollection that = (SpriteCollection) o;
        return Objects.equals(spriteList, that.spriteList);
    }
    @Override
    public int hashCode() {
        return Objects.hashCode(spriteList);
    }

    @Override
    public String toString() {
        return "SpriteCollection{" + "spriteList=" + spriteList + '}';
    }
}