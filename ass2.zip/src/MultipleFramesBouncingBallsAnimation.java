import biuoop.DrawSurface;
import biuoop.Sleeper;
import biuoop.GUI;
import java.awt.Color;
import java.util.Random;
/**
 * Ziv Glam
 * 327509105
 * assignment 2.
 */
public class MultipleFramesBouncingBallsAnimation {
    /**
     * Generates random color.
     * @return the color
     */
    public Color generateRandomColor() {
        Random random = new Random();
        // Generate random values for red, green, and blue components
        int red = random.nextInt(256);
        int green = random.nextInt(256);
        int blue = random.nextInt(256);
        // Return a new Color object with the random RGB values
        return new Color(red, green, blue);
    }
    /**
     * Generates a ball inside the frame but outside the rectangle.
     * @param frame what the ball should stay within
     * @param rct what the ball should stay out of
     * @param r radius of ball
     * @return the new ball
     */
    public Ball generateRandomBall(Rectangle frame, Rectangle rct, int r) {
        Random rnd = new Random();
        double x, y;
        do {
            //  Generates an x-coordinate within the frame bounds.
            x = rnd.nextDouble(frame.getWidth() - 2 * r) + frame.getTop().start().getX() + r;
            //  Generates a y-coordinate within the frame bounds.
            y = rnd.nextDouble(frame.getHeight() - 2 * r) + frame.getTop().start().getY() + r;
            //  Repeat if the ball overlaps with the Rectangle.
        } while (isInsideRectangle(x, y, r, rct));
        //  Returns a new ball with the randomized center and color.
        return new Ball(new Point(x, y), r, generateRandomColor());
    }
    /**
     * Checks if a ball's center and radius overlap with a rectangle.
     * @param x x-coordinate of the ball's center
     * @param y y-coordinate of the ball's center
     * @param r radius of the ball
     * @param rct the rectangle to avoid
     * @return true if the ball overlaps with the rectangle
     */
    public boolean isInsideRectangle(double x, double y, int r, Rectangle rct) {
        //  Gets Rectangle's bounds.
        double left = rct.getTop().start().getX();
        double right = rct.getTop().end().getX();
        double top = rct.getTop().start().getY();
        double bottom = rct.getBottom().start().getY();
        //  Checks if the ball overlaps with the Rectangle.
        return (x + r >= left && x - r <= right) && (y + r >= top && y - r <= bottom);
    }
    /**
     * Animates 2 Rectangles inside the frame and all the balls too.
     * @param frame of the animation
     * @param grayRect big gray rectangle
     * @param yellowRect smaller yellow rectangle
     * @param balls array of balls
     */
    public static void drawAnimation(Rectangle frame, Rectangle grayRect, Rectangle yellowRect, Ball[] balls) {
         int y;
        //  Iterate through every ball and gives it speed according to the size.
        for (int i = 0; i < balls.length; i++) {
            if (balls[i].getSize() >= 50) {
                balls[i].setVelocity(new Velocity(2, 2));
            } else {
                y = 1 / balls[i].getSize() + 5;
                balls[i].setVelocity(new Velocity(y, y));
            }
        }
        //  Draws all the balls on a surface and animates them.
        GUI gui = new GUI("title", (int) frame.getWidth(), (int) frame.getHeight());
        Sleeper sleeper = new Sleeper();
        while (true) {
            //  Draws the 2 Rectangles and paints the frame:
            DrawSurface d = gui.getDrawSurface();
            d.setColor(Color.lightGray);
            d.fillRectangle(0, 0, (int) frame.getWidth(), (int) frame.getHeight());
            d.setColor(grayRect.getC());
            //  Animates the grey rectangle.
            d.fillRectangle((int) grayRect.getTop().start().getX(), (int) grayRect.getTop().start().getY(),
                    (int) grayRect.getWidth(), (int) grayRect.getHeight());
            //  Animates the yellow rectangle.
            d.setColor(yellowRect.getC());
            d.fillRectangle((int) yellowRect.getTop().start().getX(), (int) yellowRect.getTop().start().getY(),
                    (int) yellowRect.getWidth(), (int) yellowRect.getHeight());
            //  Makes a smaller rectangle to deal with the overlapping rectangles.
            Rectangle overLapse = new Rectangle(yellowRect.getTop().start(), grayRect.getBottom().end(), Color.YELLOW);
            //  Animates the balls.
            for (int i = 0; i < balls.length; i++) {
                //  Animates the 1st half of the balls inside the grey rectangle.
                if (i < balls.length / 2) {
                    balls[i].moveOneStep(grayRect, overLapse);
                } else {  //  Animates the 2nd half of the balls outside the grey and yellow rectangles.
                    balls[i].moveOneStep(frame, grayRect, yellowRect);
                }
                d.setColor(balls[i].getColor());
                balls[i].fillOn(d);
            }
            gui.show(d);
            sleeper.sleepFor(50);
        }
    }
    /**
     * Main class.
     * @param args user's parameters
     */
    public static void main(String[] args) {
        //  Initializes the rectangles + temp rectangle for spawn points of the balls.
        Rectangle frame = new Rectangle(new Point(0, 0), new Point(800, 600));
        Rectangle grayRect = new Rectangle(new Point(50, 50), new Point(500, 500), Color.GRAY);
        Rectangle yellowRect = new Rectangle(new Point(450, 450), new Point(600, 600), Color.YELLOW);
        Rectangle temp = new Rectangle(grayRect.getTop().start(), yellowRect.getBottom().end());
        //  Initializes balls.
        Ball[] balls = new Ball[args.length];
        MultipleBouncingBallsAnimation example = new MultipleBouncingBallsAnimation();
        MultipleFramesBouncingBallsAnimation example2 = new MultipleFramesBouncingBallsAnimation();
        for (int i = 0; i < balls.length; i++) {
            //  First half gets animated to the grey rectangle.
            if (i < balls.length / 2) {
                balls[i] = example.generateRandomBall(grayRect, Integer.parseInt(args[i]) + 9);
            } else { //  2nd half gets animated outside the rectangles.
                balls[i] = example2.generateRandomBall(frame, temp, Integer.parseInt(args[i]) + 9);
            }
        }
        drawAnimation(frame, grayRect, yellowRect, balls);
    }
}
