package collisionP;

import geometryP.Point;

/**
 * Ziv Glam
 * 327509105
 * assignment 5.
 */
public class CollisionInfo {
    private Point collisionPoint;
    private Collidable collisionObject;
    /**
     * build a collisionInfo object.
     * @param collisionPoint point of collision
     * @param collisionObject what has collided
     */
    public CollisionInfo(Point collisionPoint, Collidable collisionObject) {
        this.collisionPoint = collisionPoint;
        this.collisionObject = collisionObject;
    }
    /**
     * Gets collision point from a certain collision.
     * @return collision point
     */
    public Point getCollisionPoint() {
        return this.collisionPoint;
    }
    /**
     * Gets collision Object from a certain collision.
     * @return collision Object
     */
    public Collidable getCollisionObject() {
        return this.collisionObject;
    }
}