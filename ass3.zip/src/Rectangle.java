import java.awt.Color;
import java.util.ArrayList;
/**
 * Ziv Glam
 * 327509105
 * assignment 3.
 */
public class Rectangle {
    private Point upperLeft;
    private Line top;
    private Line bottom;
    private Line left;
    private Line right;
    private Color c;
    /**
     * A builder with known width and height.
     * @param upperLeft point of the rectangle
     * @param width of rectangle
     * @param height of rectangle
     */
    public Rectangle(Point upperLeft, double width, double height) {
        this.upperLeft = upperLeft;
        Point p = new Point(upperLeft.getX() + width, upperLeft.getY() + height);
        this.top = new Line(upperLeft.getX(), upperLeft.getY(), p.getX(), upperLeft.getY());
        this.bottom = new Line(upperLeft.getX(), p.getY(), p.getX(), p.getY());
        this.left = new Line(upperLeft.getX(), upperLeft.getY(), upperLeft.getX(), p.getY());
        this.right = new Line(p.getX(), upperLeft.getY(), p.getX(), p.getY());
        this.c = null;
    }
    /**
     * A builder with  A builder with known width, height, and color.
     * @param upperLeft most top bottom point of the Rectangle
     * @param width of rectangle
     * @param height of rectangle
     * @param c filled color of the Rectangle
     */
    public Rectangle(Point upperLeft, double width, double height, Color c) {
        this.upperLeft = upperLeft;
        Point p = new Point(upperLeft.getX() + width, upperLeft.getY() + height);
        this.top = new Line(upperLeft.getX(), upperLeft.getY(), p.getX(), upperLeft.getY());
        this.bottom = new Line(upperLeft.getX(), p.getY(), p.getX(), p.getY());
        this.left = new Line(upperLeft.getX(), upperLeft.getY(), upperLeft.getX(), p.getY());
        this.right = new Line(p.getX(), upperLeft.getY(), p.getX(), p.getY());
        this.c = c;
    }
    /**
     * Returns width of rectangle using the bottom line.
     * @return bottom line length(width)
     */
    public double getWidth() {
        return this.bottom.length();
    }
    /**
     * Returns height of rectangle using the right line.
     * @return right line length(width)
     */
    public double getHeight() {
        return this.right.length();
    }
    /**
     * Return a (possibly empty) list of intersection points  with the specified line.
     * @param line to check intersections with rectangle.
     * @return List of intersection points between rectangle and line
     */
    public java.util.List<Point> intersectionPoints(Line line) {
        java.util.List<Point> list = new ArrayList<Point>();
        //  Check intersection of the line with every line of the rectangle.
        Point p = line.intersectionWith(this.top);
        if (p != null) {
            list.add(p);
        }
        p = line.intersectionWith(this.bottom);
        if (p != null) {
            list.add(p);
        }
        p = line.intersectionWith(this.right);
        if (p != null) {
            list.add(p);
        }
        p = line.intersectionWith(this.left);
        if (p != null) {
            list.add(p);
        }
        //  Return null if there are no intersections.
        if (list.isEmpty()) {
            return null;
        }
        return list;
    }
    /**
     * get right line.
     * @return this right
     */
    public Line getRight() {
        return right;
    }
    /**
     * get left line.
     * @return this left
     */
    public Line getLeft() {
        return left;
    }
    /**
     * get top line.
     * @return this top
     */
    public Line getTop() {
        return this.top;
    }
    /**
     * get bottom line.
     * @return this bottom
     */
    public Line getBottom() {
        return bottom;
    }
    /**
     * get color.
     * @return this color
     */
    public Color getC() {
        return c;
    }
    /**
     * get upperLeft point.
     * @return this upperLeft
     */
    public Point getUpperLeft() {
        return this.upperLeft;
    }
    /**
     * update upperLeft.
     * @param upperLeft
     */
    public void setUpperLeft(Point upperLeft) {
        this.upperLeft = upperLeft;
    }
}
