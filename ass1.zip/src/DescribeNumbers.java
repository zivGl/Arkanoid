/**
 * 327509105 Ziv Glam
 */
public class DescribeNumbers {
    public static int[] stringsToInts(String[] numbers){
        //  Converts a string of numbers to an array of integers:
        int[] nums = new int[numbers.length];
        for(int i = 0; i < numbers.length; i++){
            nums[i] = Integer.parseInt(numbers[i]);
        }
        return nums;
    }
    public static int min(int[] numbers) {
        //  Returns the minimum number in an array of integers:
        int min = numbers[0];
        for (int n : numbers) {
            if(n < min)
                min = n;
        }
        return min;
    }
    public static int max(int[] numbers){
        //  Returns the maximum number in an array of integers:
        int max = numbers[0];
        for (int n : numbers) {
            if(n > max)
                max = n;
        }
        return max;
    }
    public static float avg(int[] numbers){
        //  Returns the average of numbers in an array of integers:
        float avg = 0;
        for (int n : numbers) {
                avg += n;
        }
        return avg / numbers.length;
    }
    public static void main(String[] args){
        //  Calls out the functions for Task #2:
        int[] nums = DescribeNumbers.stringsToInts(args);
        System.out.println("min: " + DescribeNumbers.min(nums));
        System.out.println("max: " + DescribeNumbers.max(nums));
        System.out.println("avg: "+ DescribeNumbers.avg(nums));
    }
}
