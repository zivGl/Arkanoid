package TicTacToeP;

/**
 * Ziv Glam
 * 327509105
 * assignment 6.
 */
public class Board {
    private int boardSize;
    private char[][] board;
    /**
     * constructor of TicTacToeP.Board objects.
     * @param boardSize size of board
     */
    public Board(int boardSize) {
        this.boardSize = boardSize;
        this.setBoard();
    }

    /**
     * set the board size.
     * @param boardSize new board size
     */
    public void setBoardSize(int boardSize) {
        this.boardSize = boardSize;
    }

    /**
     * get the board's size.
     * @return board size
     */
    public int getBoardSize() {
        return this.boardSize;
    }

    /**
     * set the entire board to a default look.
     */
    private void setBoard() {
        this.board = new char[this.boardSize][this.boardSize];
        //  initialize the board.
        for (int i = 0; i < this.boardSize; ++i) {
            for (int j = 0; j < board[0].length; ++j) {
                board[i][j] = ' ';
            }
        }
    }

    /**
     * print the board.
     */
    public void print() {
        StringBuilder topBottomBoundary = new StringBuilder();

        topBottomBoundary.append("+---".repeat(Math.max(0, this.boardSize)));
        topBottomBoundary.append("+");

        for (char[] row : this.board) {
            System.out.println(topBottomBoundary);

            for (char cell : row) {
                System.out.print("| " + cell + " ");
            }
            System.out.println("|");
        }
        System.out.println(topBottomBoundary);
        System.out.println();
    }

    /**
     * update the board according to the position and mark it received.
     * @param checkMark mark to place on board
     * @param movePosition place in the board
     */
    public void placeTheMove(char checkMark, int movePosition) {
        int i = (movePosition - 1) / this.board.length;
        int j = (movePosition - 1) % this.board.length;
        this.board[i][j] = checkMark;
    }

    /**
     * check if a player has won.
     * @param mark mark to check
     * @return true if won, false otherwise
     */
    public boolean checkWin(char mark) {
        //  initialize all the booleans to true.
        boolean diag = true;
        boolean antiDiag = true;
        boolean vert;
        boolean hor;
        for (int i = 0; i < board.length; i++) {
            //  reset horizontal and vertical booleans for every row/colum.
            vert = true;
            hor = true;
            for (int j = 0; j < board.length; j++) {
                //  check if the current horizontal o vertical lines haven't won the game.
                if (board[i][j] != mark) {
                 vert = false;
                }
                if (board[j][i] != mark) {
                    hor = false;
                }
            }
            //  if one of the lines is still true, this means we have a win.
            if (vert || hor) {
                return true;
            }
            //  check if the diagonal line has not won the game.
            if (board[i][i] != mark) {
                diag = false;
            }
            //  same with the anti-diagonal.
            if (board[i][boardSize - 1 - i] != mark) {
                antiDiag = false;
            }
        }
        //  check if the current diagonal line has won the game.
        return diag || antiDiag;
    }

    /**
     * check if a move a player wants to make is in a valid position.
     * @param position position the player wants to play in
     * @return true if valid, false otherwise
     */
    public boolean isValidPosition(String position) {
        int pos = Integer.parseInt(position);
        int i = (pos - 1) / this.boardSize;
        int j = (pos - 1) % this.boardSize;
        //  check if the position is either out of bounds or caught:
        return pos <= boardSize * boardSize && pos >= 1 && this.board[i][j] != 'X' && this.board[i][j] != 'O';
    }

    /**
     * check if the board is full.
     * @return true if full, false otherwise.
     */
    public boolean isFull() {
        for (int i = 0; i < boardSize; i++) {
            for (int j = 0; j < boardSize; j++) {
                //  check if a place on the board is free.
                if (board[i][j] != 'X' && board[i][j] != 'O') {
                    return false;
                }
            }
        }
        return true;
    }
}
