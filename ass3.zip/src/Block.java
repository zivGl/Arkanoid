import biuoop.DrawSurface;
import java.awt.Color;
/**
 * Ziv Glam
 * 327509105
 * assignment 3.
 */
public class Block extends Rectangle implements Collidable, Sprite {
    private double vChange = -1.1;
    /**
     * Constructor of blocks that creates a block with a point, width, height and color.
     * @param upperLeft point of the block
     * @param width of block
     * @param height of block
     * @param c color of block
     */
    public Block(Point upperLeft, double width, double height, Color c) {
        super(upperLeft, width, height, c);
    }
    /**
     * Implements getCollision rectangle method from the interface.
     * @return a rectangle that collides right now with an object
     */
    @Override
    public Rectangle getCollisionRectangle() {
        return this;
    }
    /**
     * Notify the object that we collided with at collisionPoint with a given velocity.
     * @param collisionPoint point that we expect will collide with the block
     * @param currentVelocity velocity of given point
     * @return new velocity expected after the hit (based on the force the object inflicted on us)
     */
    @Override
    public Velocity hit(Point collisionPoint, Velocity currentVelocity) {
        //  If the point is on the bottom or top lines, change Dy in the velocity. If on the sides, change Dx.
        if (this.getTop().isOnLine(collisionPoint) || this.getBottom().isOnLine(collisionPoint)) {
            currentVelocity.setDy(currentVelocity.getDy() * this.vChange);
        } else if (this.getRight().isOnLine(collisionPoint) || this.getLeft().isOnLine(collisionPoint)) {
            currentVelocity.setDx(currentVelocity.getDx() * this.vChange);
        }
        return currentVelocity;
    }
    /**
     * Changes the change parameters in the vChange.
     * @param vChange new change in velocity after hit.
     */
    public void setVChange(double vChange) {
        this.vChange = vChange;
    }
    /**
     * Notify the block that time has passed and pops it.
     */
    @Override
    public void timePassed() {
    }
    /**
     * Draws a block with its color on a given surface. THIS CHANGES THE COLOR OF THE SURFACE.
     * @param surface where the block will get drawn on
     */
    @Override
    public void drawOn(DrawSurface surface) {
        //  Draws the outlines of the rectangle.
        surface.setColor(Color.BLACK);
        surface.drawRectangle((int) this.getUpperLeft().getX(), (int) this.getUpperLeft().getY(),
                (int) this.getWidth(), (int) this.getHeight());
        //  Fills the rectangle with its own color.
        surface.setColor(this.getC());
        surface.fillRectangle((int) this.getUpperLeft().getX(), (int) this.getUpperLeft().getY(),
                (int) this.getWidth(), (int) this.getHeight());
    }
}
