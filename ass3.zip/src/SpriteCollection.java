import biuoop.DrawSurface;

import java.util.ArrayList;
import java.util.List;
/**
 * Ziv Glam
 * 327509105
 * assignment 3.
 */
public class SpriteCollection {
    private List<Sprite> spriteList = new ArrayList<>();
    /**
     * Adds a new sprite object to the list of sprites.
     * @param s sprite object to add
     */
    public void addSprite(Sprite s) {
        spriteList.add(s);
    }
    /**
     * Calls timePassed() on all sprites.
     */
    public void notifyAllTimePassed() {
        for (Sprite s : this.spriteList) {
            s.timePassed();
        }
    }
    /**
     * Calls drawOn(d) on all sprites.
     * @param d surface to draw on
     */
    public void drawAllOn(DrawSurface d) {
        for (Sprite s : this.spriteList) {
            s.drawOn(d);
        }
    }
    /**
     * Gets the list of sprites.
     * @return sprite list
     */
    public List<Sprite> getSpriteList() {
        return this.spriteList;
    }
}
