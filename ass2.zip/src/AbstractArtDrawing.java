import biuoop.GUI;
import biuoop.DrawSurface;
import java.util.Random;
import java.awt.Color;
/**
 * Ziv Glam
 * 327509105
 * assignment 2.
 */
public class AbstractArtDrawing {
    /**
     * makes a random line.
     * @return the random line
     */
    public Line generateRandomLine() {
        Random rand = new Random();
        return new Line(rand.nextInt(350) + 1, rand.nextInt(250) + 1,
                rand.nextInt(350) + 1, rand.nextInt(250) + 1);
    }
    /**
     * Draw 10 random lines.
     */
    public void drawRandomLines() {
        // Create a window which is 400 pixels wide and 300 pixels high.
        GUI gui = new GUI("title", 400, 300);
        DrawSurface d = gui.getDrawSurface();
        //  Generates 10 random lines:
        Line[] lines = new Line[10];
        for (int i = 0; i < lines.length; i++) {
            d.setColor(Color.BLACK);
            lines[i] = generateRandomLine();
            //  Draws the lines.
            d.drawLine((int) lines[i].start().getX(), (int) lines[i].start().getY(), (int) lines[i].end().getX(),
                    (int) lines[i].end().getY());
            //  Prints the middle sections of every line.
            d.setColor(Color.BLUE);
            d.fillCircle((int) lines[i].middle().getX(), (int) lines[i].middle().getY(), 3);
        }
        //  Marks intersections.
        Point p1, p2, p3;
        for (int i = 0; i < lines.length; i++) {
            for (int j = 0; j < lines.length; j++) {
                if (lines[i].isIntersecting(lines[j])) {
                    d.setColor(Color.RED);
                    p1 = lines[i].intersectionWith(lines[j]);
                    d.fillCircle((int) p1.getX(), (int) p1.getY(), 3);
                }
            }
        }
        //  Searches for triangle.
        for (int i = 0; i < lines.length; i++) {
            for (int j = i; j < lines.length; j++) {
                for (int k = j; k < lines.length; k++) {
                    //  Checks if a triangle is present.
                    if (lines[i].isIntersecting(lines[j], lines[k]) && lines[j].isIntersecting(lines[k])) {
                        d.setColor(Color.GREEN);
                        p1 = lines[i].intersectionWith(lines[j]);
                        p2  = lines[i].intersectionWith(lines[k]);
                        p3 = lines[j].intersectionWith(lines[k]);
                        //  Marks the triangle.
                        d.drawLine((int) p1.getX(), (int) p1.getY(), (int) p2.getX(), (int) p2.getY());
                        d.drawLine((int) p3.getX(), (int) p3.getY(), (int) p2.getX(), (int) p2.getY());
                        d.drawLine((int) p1.getX(), (int) p1.getY(), (int) p3.getX(), (int) p3.getY());
                    }
                }
            }
        }
        //  Shows the result.
        gui.show(d);
    }
    /**
     * Ziv Glam
     * 327509105
     * assignment 2.
     * @param args args
     */
    public static void main(String[] args) {
        AbstractArtDrawing example = new AbstractArtDrawing();
        example.drawRandomLines();
    }
}