package TicTacToeP;

import java.util.Scanner;

/**
 * Ziv Glam
 * 327509105
 * assignment 6.
 */
 public final class TicTacToe {
    private static Scanner sc;
    private Player player1 = new Player("PLAYER-X", 1, 'X');
    private Player player2 = new Player("PLAYER-O", 2, 'O');
    private Board board;

    /**
     * constructor of TicTacToeP.TicTacToe objects with no players.
     */
    public TicTacToe() {
        sc = new Scanner(System.in);
    }

    /**
     * constructor of TicTacToeP.TicTacToe objects with players.
     * @param player1 first player
     * @param player2 second player
     */
    public TicTacToe(Player player1, Player player2) {
        this.player1 = player1;
        this.player2 = player2;
        sc = new Scanner(System.in);
    }

    /**
     * start playing the game.
     */
    public void play() {
        //  check if the player wants to start playing.
        Player currentPlayer = this.player1;
        if (!this.playAgain()) {
            this.gameOver();
            return;
        }
        //  play the game.
        while (true) {
            currentPlayer.move(this.board);
            //  check if the current move has won the game.
            if (this.board.checkWin(currentPlayer.getMarker())) {
                this.handleWinner(currentPlayer);
                //  check if the player wants to continue playing.
                if (!this.playAgain()) {
                    this.gameOver();
                    return;
                }
                //  check if no more moves can be made.
            } else if (this.board.isFull()) {
                System.out.println("The board is full. It's a tie!");
                if (!this.playAgain()) {
                    this.gameOver();
                    return;
                } else {
                    continue;
                }
            }
            //  change players for another turn.
            currentPlayer = currentPlayer == this.player1 ? this.player2 : this.player1;
        }
    }

    private void gameOver() {
        //  print the results of the game and close the streams.
        this.printResults();
        sc.close();
        this.player1.closeSC();
        this.player2.closeSC();
    }

    void handleWinner(Player winner) {
        //  print the winner.
        System.out.println("Congratulations! player " + winner.getName() + " has won the game!");
        //  increment winner's win count.
        winner.incrementNumberOfWins();
        //  print the current wins after incrementation.
        System.out.println("TicTacToeP.Player " + this.player1.getName() + " has won: "
                + this.player1.getNumberOfWins() + " time(s).");
        System.out.println("TicTacToeP.Player " + this.player2.getName() + " has won: "
                + this.player2.getNumberOfWins() + " time(s).");
    }

    private void welcome() {
        System.out.println("Hit \"y/Y\" to start a new game. Or hit any other key to exit.");
    }

    private int getBoardSize() {
        while (true) {
            System.out.print("Please enter your preferred SIZE of the board");
            System.out.println(" (from 3 to 10. 3 -> 3x3; 4 -> 4x4; 10 -> 10x10, etc): ");
            //  receive the size of board.
            if (sc.hasNextLine()) {
                String userInput = sc.nextLine();
                //  check if size is valid. if not, go over the loop again.
                if (this.verifyBoardSize(userInput)) {
                    return Integer.parseInt(userInput);
                }
                System.out.println("Invalid size. try again:");
            }
        }
    }

    boolean verifyBoardSize(String boardSize) {
        return Integer.parseInt(boardSize) >= 3;
    }

    private boolean playAgain() {
        this.welcome();
        sc = new Scanner((System.in));
        String userDecision = sc.nextLine();

        if (userDecision.equalsIgnoreCase("Y")) {
            int boardSize = this.getBoardSize();
            this.board = new Board(boardSize);
            return true;
        }

        return false;
    }

    /**
     * print the results of the games after the game ended.
     */
    public void printResults() {
        System.out.println("TicTacToeP.Player " + this.player1.getName() + " has won: "
                + this.player1.getNumberOfWins() + " time(s).");
        System.out.println("TicTacToeP.Player " + this.player2.getName() + " has won: "
                + this.player2.getNumberOfWins() + " time(s).");

        if (this.player1.getNumberOfWins() == this.player2.getNumberOfWins()) {
            System.out.println("Its a tie!");
        } else {
            String winner = this.player1.getNumberOfWins() > this.player2.getNumberOfWins() ? this.player1.getName()
                    : this.player2.getName();
            System.out.println("The final winner is: " + winner + "!!!");
        }

        System.out.println();
    }
}
