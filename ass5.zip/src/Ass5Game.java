import gameP.Game;

/**
 * Ziv Glam
 * 327509105
 * assignment 5.
 */
public class Ass5Game {
    /**
     * runs the game.
     * @param args user values
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.initialize();
        game.run();
    }
}