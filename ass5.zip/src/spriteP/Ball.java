package spriteP;

import biuoop.DrawSurface;
import gameP.Game;
import gameP.GameEnvironment;
import geometryP.Line;
import geometryP.Point;
import geometryP.Velocity;
import collisionP.CollisionInfo;
import logicP.HitListener;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Ziv Glam
 * 327509105
 * assignment 5.
 */
public class Ball implements Sprite {
    private Point center;
    private int r;
    private java.awt.Color color;
    private Velocity v;
    private GameEnvironment game;
    private List<HitListener> hitListeners;
    /**
     * Constructs a ball.
     * @param center of the ball
     * @param r for radius
     * @param color of the ball
     * @param game gameP.Game environment of the ball
     */
    public Ball(Point center, int r, java.awt.Color color, GameEnvironment game) {
        this.center = center;
        this.r = r;
        this.color = color;
        this.v = new Velocity(0, 0);
        this.game = game;
        this.hitListeners = new ArrayList<>();
    }
    /**
     * Gets x of center.
     * @return x of shapesP.Ball
     */
    public int getX() {
        return (int) this.center.getX();
    }
    /**
     * Gets y of center.
     * @return y of shapesP.Ball
     */
    public int getY() {
        return (int) this.center.getY();
    }
    /**
     * get velocity of the ball.
     * @return the current velocity
     */
    public Velocity getV() {
        return v;
    }
    /**
     * draw a filled ball on a given surface. THIS CHANGES THE COLOR OF THE SURFACE.
     * @param surface what to draw on
     */
    @Override
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.color);
        surface.fillCircle(this.getX(), this.getY(), this.r);
    }
    /**
     * Notify the ball that time has passed and moves it.
     */
    @Override
    public void timePassed() {
        this.moveOneStep();
    }
    /**
     * remove the ball from a game.
     * @param g game to remove the ball from
     */
    public void removeFromGame(Game g) {
        g.removeSprite(this);
    }
    /**
     * Sets the velocity of the ball.
     * @param v new velocity
     */
    public void setVelocity(Velocity v) {
        this.v = v;
    }
    /**
     * moves the ball one step according to its velocity.
     */
    private void moveOneStep() {
        //  Indicates whether the radius should be added or subtracted to the traj point.
        int xDir, yDir;
        if (this.v.getDx() > 0) {
            xDir = 1;
        } else if (this.v.getDx() == 0) {
            xDir = 0;
        } else {
            xDir = -1;
        }
        if (this.v.getDy() > 0) {
            yDir = 1;
        } else if (this.v.getDy() == 0) {
            yDir = 0;
        } else {
            yDir = -1;
        }
        //  Creates a line of the traj the ball will move if no collisions are made.
        Point next = new Point(this.center.getX() + this.v.getDx() + xDir * this.r,
                this.center.getY() + this.v.getDy() + yDir * this.r);
        Point parallelA1 = new Point(this.center.getX() + -1 * this.v.getDx() + xDir * this.r,
                this.center.getY() + yDir * this.r);
        Point parallelA2 = new Point(parallelA1.getX() + this.v.getDx() + xDir * this.r,
                parallelA1.getY() + this.v.getDy() + yDir * this.r);
        Point parallelB1 = new Point(this.center.getX() + this.v.getDx() + xDir * this.r,
                this.center.getY() + -1 * yDir * this.r);
        Point parallelB2 = new Point(parallelA1.getX() + this.v.getDx() + xDir * this.r,
                parallelA1.getY() + this.v.getDy() + yDir * this.r);
        Line traj = new Line(this.center, next);
        Line parallelATraj = new Line(parallelA1, parallelA2);
        Line parallelBTraj = new Line(parallelB1, parallelB2);
        //  Check the closest collision with the new lines.
        CollisionInfo trajColl = this.game.getClosestCollision(traj);
        CollisionInfo parallelATrajColl = this.game.getClosestCollision(parallelATraj);
        CollisionInfo parallelBTrajColl = this.game.getClosestCollision(parallelBTraj);
        // If we have a collision, change the speed accordingly.
        if (trajColl != null) {
            this.setVelocity(trajColl.getCollisionObject().hit(this, trajColl.getCollisionPoint(), this.v));
        } else if (parallelATrajColl != null) {
            this.setVelocity(parallelATrajColl.getCollisionObject().hit(this,
                    parallelATrajColl.getCollisionPoint(), this.v));
        } else if (parallelBTrajColl != null) {
            this.setVelocity(parallelBTrajColl.getCollisionObject().hit(this,
                    parallelBTrajColl.getCollisionPoint(), this.v));
        }
        //  Moves the point according to the new velocity.
        this.center = this.v.applyToPoint(this.center);
    }
    /**
     * gets ball color.
     * @return  color of ball
     */
    public Color getColor() {
        return color;
    }
    /**
     * change the color of ball.
     * @param color new color for the ball
     */
    public void setColor(Color color) {
        this.color = color;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Ball ball = (Ball) o;
        return r == ball.r && Objects.equals(center, ball.center) && Objects.equals(color, ball.color)
                && Objects.equals(v, ball.v) && Objects.equals(game, ball.game);
    }
    @Override
    public int hashCode() {
        return Objects.hash(center, r, color, v, game);
    }

    @Override
    public String toString() {
        return "Ball{" + "center=" + center + ", r=" + r + ", color=" + color + ", v=" + v
                + ", game=" + game + ", hitListeners=" + hitListeners + '}';
    }
}