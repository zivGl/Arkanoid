package logicP;

import java.awt.Color;
import java.util.Objects;

import biuoop.DrawSurface;

import gameP.Game;
import geometryP.Rectangle;
import spriteP.Sprite;

/**
 * Ziv Glam
 * 327509105
 * assignment 5.
 */
public class ScoreIndicator implements Sprite {
    private Rectangle rect;
    private Color color;
    private Counter scoreCounter;
    /**
     * constructor of ScoreIndicator objects.
     * @param rect rectangle that represents the indicator box
     * @param color color of rect
     * @param scoreCounter score
     */
    public ScoreIndicator(Rectangle rect, Color color, Counter scoreCounter) {
        this.rect = rect;
        this.color = color;
        this.scoreCounter = scoreCounter;
    }
    /**
     * draw the score indicator.
     * @param surface surface to draw the sprite on
     */
    @Override
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.color);
        surface.fillRectangle((int) rect.getUpperLeft().getX(), (int) rect.getUpperLeft().getY(),
                (int) rect.getWidth(), (int) rect.getHeight());
        surface.setColor(Color.BLACK);
        surface.drawRectangle((int) rect.getUpperLeft().getX(), (int) rect.getUpperLeft().getY(),
                (int) rect.getWidth(), (int) rect.getHeight());
        String score = "Score: " + this.scoreCounter.toString();
        surface.drawText((int) rect.getUpperLeft().getX() + (int) rect.getWidth() / 2 - score.length() * 3,
                (int) (rect.getUpperLeft().getY() + rect.getHeight() / 1.125), score, (int) rect.getHeight());
    }
    /**
     * do nothing for now.
     */
    @Override
    public void timePassed() { }
    /**
     * add the scoreboard to the game.
     * @param g  game to add the block to
     */
    public void addToGame(Game g) {
        g.addSprite(this);
    }
    /**
     * get current score.
     * @return current score
     */
    public Counter getScoreCounter() {
        return this.scoreCounter;
    }
    /**
     * set current score.
     * @param scoreCounter new score
     */
    public void setScoreCounter(Counter scoreCounter) {
        this.scoreCounter = scoreCounter;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ScoreIndicator that = (ScoreIndicator) o;
        return Objects.equals(rect, that.rect) && Objects.equals(color, that.color)
                && Objects.equals(scoreCounter, that.scoreCounter);
    }
    @Override
    public int hashCode() {
        return Objects.hash(rect, color, scoreCounter);
    }
    @Override
    public String toString() {
        return "ScoreIndicator{" + "rect=" + rect + ", color=" + color + ", scoreCounter="
                + scoreCounter + '}';
    }
}