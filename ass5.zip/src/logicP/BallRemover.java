package logicP;

import gameP.Game;
import spriteP.Ball;
import spriteP.Block;

import java.util.Objects;

/**
 * Ziv Glam
 * 327509105
 * assignment 5.
 */
public class BallRemover implements HitListener {
    private Game game;
    private Counter remainingBalls;
    /**
     * constructor of ballRemover objects.
     * @param game where it should listen to
     * @param remainingBalls the remaining number of balls in game
     */
    public BallRemover(Game game, Counter remainingBalls) {
        this.game = game;
        this.remainingBalls = remainingBalls;
    }
    /**
     * remove the hitter ball from the game and decrease the remaining balls number.
     * @param beingHit what got hit
     * @param hitter the thing that hit it
     */
    @Override
    public void hitEvent(Block beingHit, Ball hitter) {
        hitter.removeFromGame(this.game);
        this.remainingBalls.decrease(1);
    }
    /**
     * get the remaining balls number.
     * @return remaining balls counter
     */
    public Counter getRemainingBalls() {
        return this.remainingBalls;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null) {
            return false;
        }
        BallRemover that = (BallRemover) o;
        return Objects.equals(game, that.game) && Objects.equals(remainingBalls, that.remainingBalls);
    }
    @Override
    public int hashCode() {
        return Objects.hash(game, remainingBalls);
    }

    @Override
    public String toString() {
        return "BallRemover{" + "game=" + game + ", remainingBalls=" + remainingBalls + '}';
    }
}
