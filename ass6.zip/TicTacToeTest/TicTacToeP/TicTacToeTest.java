package TicTacToeP;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

public class TicTacToeTest {
     private Player p = new Player("PLAYER-X", 1, 'X');
     private TicTacToe game = new TicTacToe();
     private Board board = new Board(3);
     @Test
    public void checkWinnerTest() {
         //  test no win.
         assertFalse(board.checkWin('X'));
         assertFalse(board.checkWin('O'));
         //  test row win.
         board.placeTheMove('X', 1);
         board.placeTheMove('X', 2);
         board.placeTheMove('X', 3);
         assertTrue(board.checkWin('X'));
         assertFalse(board.checkWin('O'));
         //  test colum win.
         Board b2 = new Board(board.getBoardSize());
         b2.placeTheMove('O', 1);
         b2.placeTheMove('O', 4);
         b2.placeTheMove('O', 7);
         assertTrue(b2.checkWin('O'));
         assertFalse(b2.checkWin('X'));
         //  test diagonal win.
         Board b3 = new Board(board.getBoardSize());
         b3.placeTheMove('O', 1);
         b3.placeTheMove('O', 5);
         b3.placeTheMove('O', 9);
         assertTrue(b3.checkWin('O'));
         assertFalse(b3.checkWin('X'));
         //  test anti-diagonal win.
         Board b4 = new Board(board.getBoardSize());
         b4.placeTheMove('O', 3);
         b4.placeTheMove('O', 5);
         b4.placeTheMove('O', 7);
         assertTrue(b4.checkWin('O'));
         assertFalse(b4.checkWin('X'));
    }

     @Test
    public void handleWinnerTest() {
         assertEquals(0, p.getNumberOfWins());
         game.handleWinner(p);
         assertEquals(1, p.getNumberOfWins());
    }

     @Test
    public void isValidPositionTest() {
         board.placeTheMove('X', 1);
         assertFalse(board.isValidPosition("1"));
         assertTrue(board.isValidPosition("3"));
    }

     @Test
    public void isFullTest() {
         //  check if an empty board is full.
         board = new Board(3);
         assertFalse(board.isFull());
         board.placeTheMove('X', 1);
         assertFalse(board.isFull());
         assertFalse(board.isFull());
         board.placeTheMove('X', 2);
         assertFalse(board.isFull());
         board.placeTheMove('X', 3);
         assertFalse(board.isFull());
         board.placeTheMove('X', 4);
         assertFalse(board.isFull());
         board.placeTheMove('X', 5);
         assertFalse(board.isFull());
         board.placeTheMove('X', 6);
         assertFalse(board.isFull());
         board.placeTheMove('X', 7);
         assertFalse(board.isFull());
         board.placeTheMove('X', 8);
         assertFalse(board.isFull());
         board.placeTheMove('X', 9);
         //  check if a full board is full.
         assertTrue(board.isFull());
    }

     @Test
    public void verifyBoardSizeTest() {
         assertFalse(game.verifyBoardSize("1"));
         assertTrue(game.verifyBoardSize("4"));
    }
}