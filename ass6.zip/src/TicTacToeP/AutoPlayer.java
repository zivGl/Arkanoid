package TicTacToeP;
import java.util.List;
import java.util.Random;
import java.util.ArrayList;

/**
 * Ziv Glam
 * 327509105
 * assignment 6.
 */
public class AutoPlayer extends Player {
    private final Random rnd;

    /**
     * Constructor of AutoPlayer objects.
     * @param name name of player
     * @param id id of player
     * @param marker symbol of player
     */
    public AutoPlayer(String name, int id, char marker) {
        super(name, id, marker);
        this.rnd = new Random();
    }

    @Override
    public void move(Board board) {
        List<Integer> freePos = getFreePos(board);
        int movePos = freePos.get(rnd.nextInt(freePos.size()));
        //  print the move.
        System.out.println("Player " + getName() + ", please enter your move. (enter a value from 1 - "
                + board.getBoardSize() * board.getBoardSize() + ")");
        board.print();
        System.out.println(movePos);
        board.placeTheMove(getMarker(), movePos);
    }
    /**
     * get free positions.
     * @param board board of the game
     * @return list of all free positions
     */
    private List<Integer> getFreePos(Board board) {
        List<Integer> free = new ArrayList<>();
        for (int i = 1; i <= board.getBoardSize() * board.getBoardSize(); i++) {
            //  check if a position is free.
            if (board.isValidPosition(String.valueOf(i))) {
                free.add(i);
            }
        }
        return free;
    }
}